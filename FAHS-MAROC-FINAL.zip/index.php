<?php
/**
 * FAHS MAROC - Public Homepage
 * Product directory with category filtering
 */
require_once __DIR__ . '/includes/config.php';

$db = getDBConnection();

// Get search query
$search = trim($_GET['search'] ?? '');

// Get selected category
$selectedCategory = (int)($_GET['cat'] ?? 0);

// Fetch all categories for navigation
$catStmt = $db->query("SELECT id, name FROM categories ORDER BY name ASC");
$categories = $catStmt->fetchAll();

// Build product query
$whereClauses = [];
$params = [];

if ($selectedCategory > 0) {
    $whereClauses[] = "p.category_id = ?";
    $params[] = $selectedCategory;
}

if ($search) {
    $whereClauses[] = "(p.name LIKE ? OR p.brand LIKE ?)";
    $searchParam = "%$search%";
    $params = array_merge($params, [$searchParam, $searchParam]);
}

$whereSql = $whereClauses ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

// Fetch products
$query = "SELECT p.*, c.name as category_name 
          FROM products p 
          LEFT JOIN categories c ON p.category_id = c.id 
          $whereSql 
          ORDER BY p.score DESC, p.name ASC";
$stmt = $db->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Get stats
$totalProducts = $db->query("SELECT COUNT(*) as count FROM products")->fetch()['count'];
$totalCategories = $db->query("SELECT COUNT(*) as count FROM categories")->fetch()['count'];

// Helper function for score badge color
function getScoreBadgeClass($score) {
    if ($score === null) return 'bg-gray-100 text-gray-600';
    if ($score >= 70) return 'bg-green-500 text-white';
    if ($score >= 40) return 'bg-orange-500 text-white';
    return 'bg-red-500 text-white';
}

// Helper function for score text
function getScoreLabel($score) {
    if ($score === null) return 'N/A';
    if ($score >= 70) return 'Excellent';
    if ($score >= 40) return 'Average';
    return 'Poor';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="FAHS MAROC - Your trusted guide for food quality and health in Morocco. Discover nutritious products and make informed choices.">
    <title>FAHS MAROC - Food Quality & Health Directory</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        fahs: {
                            green: '#2D5A27',
                            'green-light': '#4A7C43',
                            'green-dark': '#1E3D1A',
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        body { font-family: 'Inter', sans-serif; }
        .gradient-hero {
            background: linear-gradient(135deg, #2D5A27 0%, #4A7C43 100%);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        .category-scroll::-webkit-scrollbar {
            height: 6px;
        }
        .category-scroll::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }
        .category-scroll::-webkit-scrollbar-thumb {
            background: #2D5A27;
            border-radius: 3px;
        }
    </style>
</head>
<body class="bg-gray-50">
    
    <!-- Navigation Header -->
    <header class="bg-white shadow-sm sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <!-- Logo -->
                <a href="index.php" class="flex items-center space-x-3">
                    <img src="assets/images/logo.png" 
                         alt="FAHS MAROC Logo" 
                         class="h-10 w-10 object-contain"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="hidden w-10 h-10 bg-fahs-green rounded-full items-center justify-center">
                        <span class="text-white font-bold text-lg">F</span>
                    </div>
                    <span class="text-xl font-bold text-gray-800">FAHS MAROC</span>
                </a>
                
                <!-- Navigation Links -->
                <nav class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-fahs-green font-medium">Home</a>
                    <a href="about.php" class="text-gray-600 hover:text-fahs-green transition-colors">About</a>
                    <a href="admin/login.php" class="text-gray-600 hover:text-fahs-green transition-colors">Admin</a>
                </nav>
                
                <!-- Search Bar -->
                <form method="GET" action="" class="flex items-center">
                    <div class="relative">
                        <input type="text" 
                               name="search" 
                               placeholder="Search products..."
                               value="<?php echo htmlspecialchars($search); ?>"
                               class="w-48 lg:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-full text-sm focus:ring-2 focus:ring-fahs-green focus:border-transparent transition-all">
                        <svg class="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                    <?php if ($selectedCategory > 0): ?>
                        <input type="hidden" name="cat" value="<?php echo $selectedCategory; ?>">
                    <?php endif; ?>
                </form>
                
                <!-- Mobile Menu Button -->
                <button id="mobile-menu-btn" class="md:hidden p-2 rounded-lg hover:bg-gray-100">
                    <svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t">
            <div class="px-4 py-3 space-y-2">
                <a href="index.php" class="block px-3 py-2 text-fahs-green font-medium rounded-lg bg-green-50">Home</a>
                <a href="about.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">About</a>
                <a href="admin/login.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">Admin</a>
            </div>
        </div>
    </header>
    
    <!-- Hero Section -->
    <section class="gradient-hero text-white py-16 lg:py-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl lg:text-5xl font-bold mb-4">
                Discover Food Quality in Morocco
            </h1>
            <p class="text-xl text-green-100 max-w-2xl mx-auto mb-8">
                Your trusted guide to healthy, quality products. Make informed choices for you and your family.
            </p>
            <div class="flex flex-wrap justify-center gap-4 text-sm">
                <span class="bg-white/20 px-4 py-2 rounded-full">
                    <?php echo number_format($totalProducts); ?> Products
                </span>
                <span class="bg-white/20 px-4 py-2 rounded-full">
                    <?php echo number_format($totalCategories); ?> Categories
                </span>
                <span class="bg-white/20 px-4 py-2 rounded-full">
                    100% Moroccan Focus
                </span>
            </div>
        </div>
    </section>
    
    <!-- Category Navigation -->
    <section class="bg-white border-b sticky top-16 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div class="flex items-center space-x-2 overflow-x-auto category-scroll pb-2">
                <span class="text-gray-500 text-sm font-medium whitespace-nowrap mr-2">Categories:</span>
                
                <!-- All Categories Button -->
                <a href="index.php<?php echo $search ? '?search=' . urlencode($search) : ''; ?>" 
                   class="whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-all <?php echo $selectedCategory === 0 ? 'bg-fahs-green text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                    All
                </a>
                
                <!-- Category Buttons -->
                <?php foreach ($categories as $category): ?>
                    <a href="?cat=<?php echo $category['id']; ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" 
                       class="whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-all <?php echo $selectedCategory === (int)$category['id'] ? 'bg-fahs-green text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        <?php echo htmlspecialchars($category['name']); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        <!-- Section Header -->
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">
                    <?php if ($selectedCategory > 0): ?>
                        <?php 
                            $selectedCatName = '';
                            foreach ($categories as $cat) {
                                if ($cat['id'] == $selectedCategory) {
                                    $selectedCatName = $cat['name'];
                                    break;
                                }
                            }
                        ?>
                        <?php echo htmlspecialchars($selectedCatName); ?>
                    <?php elseif ($search): ?>
                        Search Results
                    <?php else: ?>
                        All Products
                    <?php endif; ?>
                </h2>
                <p class="text-gray-500 mt-1">
                    <?php echo count($products); ?> product<?php echo count($products) !== 1 ? 's' : ''; ?> found
                </p>
            </div>
            
            <!-- Active Filters -->
            <?php if ($search || $selectedCategory > 0): ?>
                <div class="mt-4 sm:mt-0 flex items-center space-x-2">
                    <span class="text-sm text-gray-500">Active filters:</span>
                    <?php if ($search): ?>
                        <span class="inline-flex items-center px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-sm">
                            Search: "<?php echo htmlspecialchars($search); ?>"
                            <a href="?<?php echo $selectedCategory > 0 ? 'cat=' . $selectedCategory : ''; ?>" class="ml-2 hover:text-blue-900">&times;</a>
                        </span>
                    <?php endif; ?>
                    <?php if ($selectedCategory > 0): ?>
                        <span class="inline-flex items-center px-3 py-1 rounded-full bg-green-100 text-green-700 text-sm">
                            Category: <?php echo htmlspecialchars($selectedCatName); ?>
                            <a href="?<?php echo $search ? 'search=' . urlencode($search) : ''; ?>" class="ml-2 hover:text-green-900">&times;</a>
                        </span>
                    <?php endif; ?>
                    <a href="index.php" class="text-sm text-red-600 hover:text-red-800 underline">Clear all</a>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Product Grid -->
        <?php if (!empty($products)): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <?php foreach ($products as $product): ?>
                    <article class="bg-white rounded-2xl shadow-md overflow-hidden card-hover flex flex-col">
                        <!-- Product Image -->
                        <div class="relative h-48 bg-gray-100 overflow-hidden">
                            <?php if ($product['image_url']): ?>
                                <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                                     class="w-full h-full object-cover"
                                     loading="lazy"
                                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                <div class="hidden w-full h-full items-center justify-center bg-gray-200">
                                    <svg class="w-16 h-16 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                    </svg>
                                </div>
                            <?php else: ?>
                                <div class="w-full h-full flex items-center justify-center bg-gray-200">
                                    <svg class="w-16 h-16 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                    </svg>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Score Badge -->
                            <div class="absolute top-3 right-3">
                                <div class="flex flex-col items-center">
                                    <div class="w-12 h-12 rounded-full flex items-center justify-center text-sm font-bold shadow-lg <?php echo getScoreBadgeClass($product['score']); ?>">
                                        <?php echo $product['score'] ?? '-'; ?>
                                    </div>
                                    <span class="text-xs font-medium text-white bg-black/50 px-2 py-0.5 rounded-full mt-1">
                                        <?php echo getScoreLabel($product['score']); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <!-- Category Badge -->
                            <?php if ($product['category_name']): ?>
                                <div class="absolute top-3 left-3">
                                    <span class="bg-white/90 backdrop-blur-sm text-gray-700 text-xs font-medium px-3 py-1 rounded-full shadow-sm">
                                        <?php echo htmlspecialchars($product['category_name']); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Product Info -->
                        <div class="p-5 flex flex-col flex-grow">
                            <h3 class="font-semibold text-gray-800 text-lg mb-1 line-clamp-2">
                                <?php echo htmlspecialchars($product['name']); ?>
                            </h3>
                            
                            <?php if ($product['brand']): ?>
                                <p class="text-gray-500 text-sm mb-3">
                                    <?php echo htmlspecialchars($product['brand']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <!-- Additives Status -->
                            <?php if ($product['additives_status']): ?>
                                <div class="mb-3">
                                    <span class="inline-flex items-center text-xs <?php echo stripos($product['additives_status'], 'No') !== false ? 'text-green-600 bg-green-50' : 'text-orange-600 bg-orange-50'; ?> px-2 py-1 rounded-full">
                                        <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                            <?php if (stripos($product['additives_status'], 'No') !== false): ?>
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                            <?php else: ?>
                                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                            <?php endif; ?>
                                        </svg>
                                        <?php echo htmlspecialchars($product['additives_status']); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Quick Nutrition Info -->
                            <div class="grid grid-cols-2 gap-2 text-xs text-gray-500 mb-4">
                                <?php if ($product['calories']): ?>
                                    <div class="flex items-center">
                                        <svg class="w-4 h-4 mr-1 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z"/>
                                        </svg>
                                        <?php echo $product['calories']; ?> kcal
                                    </div>
                                <?php endif; ?>
                                <?php if ($product['protein']): ?>
                                    <div class="flex items-center">
                                        <svg class="w-4 h-4 mr-1 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"/>
                                        </svg>
                                        <?php echo $product['protein']; ?>g protein
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- View Details Button -->
                            <a href="product_details.php?id=<?php echo $product['id']; ?>" 
                               class="mt-auto block w-full text-center bg-fahs-green text-white py-3 rounded-xl font-medium hover:bg-fahs-green-dark transition-colors">
                                View Details
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <!-- Empty State -->
            <div class="text-center py-16">
                <div class="w-24 h-24 bg-gradient-to-br from-fahs-green to-fahs-green-light rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <svg class="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-semibold text-gray-800 mb-2">No products found</h3>
                <p class="text-gray-500 mb-2 max-w-md mx-auto">
                    <?php if ($search): ?>
                        No products match your search "<?php echo htmlspecialchars($search); ?>"
                    <?php elseif ($selectedCategory > 0): ?>
                        No products in this category yet
                    <?php else: ?>
                        No products available at the moment
                    <?php endif; ?>
                </p>
                <p class="text-fahs-green font-medium mb-6">
                    Help us expand by suggesting a product on our Instagram!
                </p>
                <div class="flex flex-wrap justify-center gap-4">
                    <?php if ($search || $selectedCategory > 0): ?>
                        <a href="index.php" class="inline-flex items-center px-6 py-3 bg-fahs-green text-white rounded-xl font-medium hover:bg-fahs-green-dark transition-colors">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                            </svg>
                            View All Products
                        </a>
                    <?php endif; ?>
                    <a href="https://instagram.com/fahs.maroc" target="_blank" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 text-white rounded-xl font-medium hover:opacity-90 transition-opacity">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                        </svg>
                        @fahs.maroc
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </main>
    
    <!-- Footer -->
    <footer class="bg-white border-t mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="flex items-center space-x-2 mb-4 md:mb-0">
                    <div class="w-8 h-8 bg-fahs-green rounded-full flex items-center justify-center">
                        <span class="text-white font-bold text-sm">F</span>
                    </div>
                    <span class="font-semibold text-gray-800">FAHS MAROC</span>
                </div>
                <p class="text-gray-500 text-sm">
                    &copy; <?php echo date('Y'); ?> FAHS MAROC. Your guide to food quality in Morocco.
                </p>
            </div>
        </div>
    </footer>
    
    <!-- Mobile Menu Script -->
    <script>
        document.getElementById('mobile-menu-btn')?.addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
    
</body>
</html>
