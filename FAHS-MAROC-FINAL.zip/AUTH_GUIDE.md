# FAHS MAROC - Admin Authentication Guide

## Quick Setup

### 1. Create Admin User (One-time)

Run this SQL in phpMyAdmin to create your admin account:

```sql
-- Option 1: Using pre-hashed password (password: 'yourpassword')
INSERT INTO admins (username, password, email, is_active) 
VALUES (
    'your_username', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
    'your@email.com',
    1
);

-- Option 2: Generate your own hash with PHP
-- Create a temporary file with:
-- <?php echo password_hash('your_password', PASSWORD_BCRYPT);
```

### 2. Protect Admin Pages

Add this at the **very top** of any admin page you want to protect:

```php
<?php
require_once __DIR__ . '/../includes/auth_check.php';
// If not logged in, user will be redirected to login.php
?>
```

### 3. Login Flow

```
User visits /admin/dashboard.php
        ↓
auth_check.php checks $_SESSION['admin_id']
        ↓
If NOT set → Redirect to /admin/login.php
        ↓
User enters credentials
        ↓
login.php verifies with password_verify()
        ↓
If valid → Set $_SESSION['admin_id'] → Redirect to dashboard
```

## Security Features Included

| Feature | Implementation |
|---------|---------------|
| Password Hashing | `password_hash()` / `password_verify()` |
| CSRF Protection | Token on all forms |
| Session Timeout | 2 hours of inactivity |
| Session Regeneration | Every 30 minutes |
| SQL Injection | PDO prepared statements |
| XSS Protection | `htmlspecialchars()` output |

## Session Variables Available After Login

```php
$_SESSION['admin_id']       // Admin user ID
$_SESSION['admin_username'] // Admin username
$_SESSION['last_activity']  // Timestamp of last action
```

## Logout

Simply visit `/admin/logout.php` - it will:
1. Clear all session data
2. Destroy the session cookie
3. Redirect to login page with success message

## Default Credentials (For Testing)

> ⚠️ **CHANGE THESE IMMEDIATELY IN PRODUCTION!**

- **Username**: `admin`
- **Password**: `admin123`

## File Structure

```
includes/
├── auth_check.php    # Include this to protect pages
├── config.php        # DB + helper functions
├── header.php        # Site header
└── footer.php        # Site footer

admin/
├── login.php         # Login form
├── logout.php        # Logout handler
└── dashboard.php     # Protected page example
```
