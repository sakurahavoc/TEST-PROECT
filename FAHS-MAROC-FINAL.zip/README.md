# FAHS MAROC - Health & Quality Product Directory

A digital guide for food quality and health in Morocco. Built with PHP and MySQL.

## Features

- **Product Directory**: Browse and search food products with detailed nutritional information
- **Health Scoring**: 0-100 health score system for quick product evaluation
- **Category Management**: Organized product categories for easy navigation
- **Admin Panel**: Secure backend for managing products and categories
- **Responsive Design**: Mobile-friendly interface using Tailwind CSS

## Folder Structure

```
fahs_maroc/
├── admin/                  # Admin panel files
│   ├── login.php          # Admin login page
│   ├── logout.php         # Logout handler
│   ├── dashboard.php      # Admin dashboard
│   ├── products-add.php   # Add new product (to be created)
│   ├── products-edit.php  # Edit product (to be created)
│   ├── products-delete.php # Delete product (to be created)
│   └── categories-manage.php # Manage categories (to be created)
├── assets/                # Static assets
│   ├── css/              # Custom CSS files
│   ├── js/               # JavaScript files
│   └── images/           # Local images (if not using external URLs)
├── database/             # Database files
│   └── schema.sql        # Database schema
├── includes/             # Reusable PHP components
│   ├── config.php        # Database configuration & helper functions
│   ├── header.php        # Site header template
│   └── footer.php        # Site footer template
├── index.php             # Homepage
├── products.php          # Product listing page (to be created)
├── product.php           # Single product page (to be created)
├── categories.php        # Categories page (to be created)
├── about.php             # About page (to be created)
├── .htaccess             # Apache configuration
└── README.md             # This file
```

## Installation

### 1. Database Setup

1. Create a MySQL database on your Aeonfree hosting
2. Import the database schema:
   ```bash
   mysql -u your_username -p your_database < database/schema.sql
   ```
   Or use phpMyAdmin to import `database/schema.sql`

### 2. Configuration

1. Edit `includes/config.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'your_database_name');
   define('DB_USER', 'your_database_username');
   define('DB_PASS', 'your_database_password');
   define('APP_URL', 'https://your-domain.aeonfree.com');
   ```

2. Update the admin password (IMPORTANT for security):
   ```sql
   -- Generate new hash
   -- Use PHP: password_hash('your_new_password', PASSWORD_BCRYPT)
   
   UPDATE admins SET password = 'your_new_hash' WHERE username = 'admin';
   ```

### 3. Upload Files

Upload all files to your Aeonfree hosting public_html directory.

## Default Admin Credentials

- **Username**: `admin`
- **Password**: `admin123` ⚠️ **CHANGE IMMEDIATELY AFTER INSTALLATION!**

## Color Scheme

| Color | Hex Code | Usage |
|-------|----------|-------|
| Primary Green | `#2D5A27` | Headers, buttons, primary actions |
| Green Light | `#4A7C43` | Hover states, gradients |
| Green Dark | `#1E3D1A` | Footer, dark elements |
| White | `#FFFFFF` | Backgrounds, text on dark |

## Security Features

- PDO prepared statements (SQL injection protection)
- Password hashing with bcrypt
- CSRF token protection
- XSS protection via output escaping
- Secure session handling
- .htaccess security rules

## Next Steps (Phase 2)

1. Create product management CRUD pages
2. Implement product search functionality
3. Add category filtering
4. Create product detail page
5. Add image upload functionality (optional)

## License

This project is proprietary to FAHS MAROC.

## Support

For support or questions, contact: contact@fahsmaroc.ma
