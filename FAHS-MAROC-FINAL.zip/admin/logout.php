<?php
/**
 * FAHS MAROC - Admin Logout
 */
require_once __DIR__ . '/../includes/config.php';

// Clear all session data
$_SESSION = [];

// Destroy session cookie
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', [
        'expires' => time() - 3600,
        'path' => '/',
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
}

// Destroy session
session_destroy();

// Redirect to login page
setFlashMessage('success', 'You have been logged out successfully.');
redirect(APP_URL . '/admin/login.php');
?>
