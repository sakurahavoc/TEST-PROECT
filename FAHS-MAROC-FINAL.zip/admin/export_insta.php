<?php
/**
 * =============================================================================
 * FAHS MAROC - Instagram Image Export Generator
 * =============================================================================
 * 
 * Generates professional 1080x1080px analysis graphics for Instagram posts.
 * "NAQI" Style Product Analysis - Professional Health & Quality Visuals
 * 
 * Usage: admin/export_insta.php?id=PRODUCT_ID
 * 
 * @package FAHS_MAROC
 * @author FAHS Team
 * @version 2.0.0
 * @requires PHP 8.0+, GD Library
 * =============================================================================
 */

// =============================================================================
// SECURITY LAYER 1: Authentication Check
// =============================================================================

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth_check.php';

// =============================================================================
// CONFIGURATION CONSTANTS
// =============================================================================

define('CANVAS_WIDTH', 1080);
define('CANVAS_HEIGHT', 1080);
define('LOGO_PATH', __DIR__ . '/../assets/FAHS.png');
define('FONTS_DIR', __DIR__ . '/../assets/fonts/');
define('DEFAULT_FONT', FONTS_DIR . 'Inter-Bold.ttf');
define('ARABIC_FONT', FONTS_DIR . 'Cairo-Bold.ttf');

// Font sizes
define('FONT_SIZE_LOGO', 28);
define('FONT_SIZE_TAGLINE', 32);
define('FONT_SIZE_TITLE', 36);
define('FONT_SIZE_SUBTITLE', 24);
define('FONT_SIZE_SCORE', 64);
define('FONT_SIZE_SCORE_LABEL', 18);
define('FONT_SIZE_NUTRIENT_LABEL', 22);
define('FONT_SIZE_NUTRIENT_VALUE', 26);
define('FONT_SIZE_SECTION', 28);
define('FONT_SIZE_HANDLE', 20);

// =============================================================================
// CATEGORY COLOR SCHEME - Soft Pastel Gradients
// =============================================================================

/**
 * Get background colors based on category ID
 * Returns array with 'primary', 'secondary', 'accent' RGB values
 */
function getCategoryColors(int $categoryId): array {
    $schemes = [
        // Dairy Products - Soft Blue
        1 => [
            'primary'   => [135, 206, 235],   // Sky Blue
            'secondary' => [176, 224, 230],   // Powder Blue
            'accent'    => [70, 130, 180],    // Steel Blue
            'name'      => 'Dairy'
        ],
        // Beverages - Soft Teal
        2 => [
            'primary'   => [72, 201, 176],    // Medium Turquoise
            'secondary' => [128, 222, 203],   // Light Sea Green
            'accent'    => [26, 188, 156],    // Turquoise
            'name'      => 'Beverages'
        ],
        // Snacks - Soft Purple
        3 => [
            'primary'   => [187, 143, 206],   // Light Purple
            'secondary' => [215, 189, 226],   // Lavender
            'accent'    => [155, 89, 182],    // Amethyst
            'name'      => 'Snacks'
        ],
        // Breakfast Cereals - Soft Yellow
        4 => [
            'primary'   => [247, 220, 111],   // Light Yellow
            'secondary' => [252, 243, 207],   // Cream
            'accent'    => [241, 196, 15],    // Sunflower
            'name'      => 'Breakfast'
        ],
        // Oils & Fats - Soft Orange
        5 => [
            'primary'   => [248, 196, 113],   // Light Orange
            'secondary' => [250, 215, 160],   // Peach
            'accent'    => [230, 126, 34],    // Carrot
            'name'      => 'Oils'
        ],
        // Baby Food - Soft Pink
        6 => [
            'primary'   => [247, 143, 179],   // Light Pink
            'secondary' => [250, 177, 160],   // Salmon
            'accent'    => [236, 112, 99],    // Coral
            'name'      => 'Baby Food'
        ],
        // Bakery - Soft Brown
        7 => [
            'primary'   => [210, 180, 140],   // Tan
            'secondary' => [222, 184, 135],   // Burlywood
            'accent'    => [180, 130, 70],    // Peru
            'name'      => 'Bakery'
        ],
        // Frozen Foods - Soft Cyan
        8 => [
            'primary'   => [133, 193, 233],   // Light Blue
            'secondary' => [174, 214, 241],   // Pale Blue
            'accent'    => [52, 152, 219],    // Blue
            'name'      => 'Frozen'
        ],
        // Natural/Bio - Soft Green (Default)
        9 => [
            'primary'   => [130, 224, 170],   // Light Green
            'secondary' => [169, 223, 191],   // Mint
            'accent'    => [46, 204, 113],    // Emerald
            'name'      => 'Natural'
        ],
    ];
    
    return $schemes[$categoryId] ?? $schemes[9]; // Default to Natural colors
}

// =============================================================================
// SCORE COLOR LOGIC
// =============================================================================

/**
 * Get score badge colors based on health score
 */
function getScoreColors(?int $score): array {
    if ($score === null) {
        return [
            'bg'    => [149, 165, 166],  // Gray
            'text'  => [255, 255, 255],
            'label' => 'Not Rated'
        ];
    }
    
    if ($score >= 70) {
        return [
            'bg'    => [46, 204, 113],   // Green
            'text'  => [255, 255, 255],
            'label' => 'Excellent'
        ];
    }
    
    if ($score >= 40) {
        return [
            'bg'    => [230, 126, 34],   // Orange
            'text'  => [255, 255, 255],
            'label' => 'Average'
        ];
    }
    
    return [
        'bg'    => [231, 76, 60],      // Red
        'text'  => [255, 255, 255],
        'label' => 'Poor'
    ];
}

/**
 * Get nutrient health indicator color
 */
function getNutrientHealthColor(string $nutrient, ?float $value): array {
    if ($value === null) {
        return ['r' => 149, 'g' => 165, 'b' => 166]; // Gray
    }
    
    // Health thresholds (per 100g)
    $thresholds = [
        'protein'       => ['min' => 5,  'max' => PHP_FLOAT_MAX],  // Higher is better
        'calories'      => ['min' => 0,  'max' => 200],             // Lower is better
        'sugar'         => ['min' => 0,  'max' => 10],              // Lower is better
        'salt'          => ['min' => 0,  'max' => 1.5],             // Lower is better
        'saturated_fat' => ['min' => 0,  'max' => 5],               // Lower is better
    ];
    
    $threshold = $thresholds[$nutrient] ?? ['min' => 0, 'max' => PHP_FLOAT_MAX];
    
    // For protein, higher is better
    if ($nutrient === 'protein') {
        return $value >= $threshold['min']
            ? ['r' => 46, 'g' => 204, 'b' => 113]   // Green - Good
            : ['r' => 231, 'g' => 76, 'b' => 60];    // Red - Low
    }
    
    // For others, lower is better
    return $value <= $threshold['max']
        ? ['r' => 46, 'g' => 204, 'b' => 113]       // Green - Good
        : ['r' => 231, 'g' => 76, 'b' => 60];        // Red - High
}

// =============================================================================
// FONT HANDLING
// =============================================================================

/**
 * Get available font path
 */
function getFontPath(string $type = 'default'): string {
    $fonts = [
        'default' => [
            FONTS_DIR . 'Inter-Bold.ttf',
            FONTS_DIR . 'Cairo-Bold.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
            '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
        ],
        'arabic' => [
            FONTS_DIR . 'Cairo-Bold.ttf',
            FONTS_DIR . 'NotoSansArabic-Bold.ttf',
            FONTS_DIR . 'Inter-Bold.ttf',
        ]
    ];
    
    $fontList = $fonts[$type] ?? $fonts['default'];
    
    foreach ($fontList as $font) {
        if (file_exists($font)) {
            return $font;
        }
    }
    
    return null;
}

// =============================================================================
// IMAGE DRAWING HELPERS
// =============================================================================

/**
 * Create gradient background
 */
function createGradientBackground($image, array $color1, array $color2): void {
    for ($y = 0; $y < CANVAS_HEIGHT; $y++) {
        $ratio = $y / CANVAS_HEIGHT;
        $r = intval($color1[0] + ($color2[0] - $color1[0]) * $ratio);
        $g = intval($color1[1] + ($color2[1] - $color1[1]) * $ratio);
        $b = intval($color1[2] + ($color2[2] - $color1[2]) * $ratio);
        $color = imagecolorallocate($image, $r, $g, $b);
        imageline($image, 0, $y, CANVAS_WIDTH, $y, $color);
    }
}

/**
 * Draw rounded rectangle
 */
function drawRoundedRectangle($image, int $x, int $y, int $width, int $height, int $radius, int $color): void {
    // Main rectangle
    imagefilledrectangle($image, $x + $radius, $y, $x + $width - $radius, $y + $height, $color);
    imagefilledrectangle($image, $x, $y + $radius, $x + $width, $y + $height - $radius, $color);
    
    // Corners
    imagefilledellipse($image, $x + $radius, $y + $radius, $radius * 2, $radius * 2, $color);
    imagefilledellipse($image, $x + $width - $radius, $y + $radius, $radius * 2, $radius * 2, $color);
    imagefilledellipse($image, $x + $radius, $y + $height - $radius, $radius * 2, $radius * 2, $color);
    imagefilledellipse($image, $x + $width - $radius, $y + $height - $radius, $radius * 2, $radius * 2, $color);
}

/**
 * Draw shadow for elements
 */
function drawShadow($image, int $x, int $y, int $width, int $height, int $radius = 0, int $opacity = 30): void {
    $shadowColor = imagecolorallocatealpha($image, 0, 0, 0, $opacity);
    $offset = 8;
    
    if ($radius > 0) {
        drawRoundedRectangle($image, $x + $offset, $y + $offset, $width, $height, $radius, $shadowColor);
    } else {
        imagefilledrectangle($image, $x + $offset, $y + $offset, $x + $width + $offset, $y + $height + $offset, $shadowColor);
    }
}

/**
 * Wrap text to fit width
 */
function wrapText($image, string $font, int $fontSize, string $text, int $maxWidth): array {
    $words = explode(' ', $text);
    $lines = [];
    $currentLine = '';
    
    foreach ($words as $word) {
        $testLine = $currentLine ? $currentLine . ' ' . $word : $word;
        $bbox = imagettfbbox($fontSize, 0, $font, $testLine);
        $lineWidth = $bbox[2] - $bbox[0];
        
        if ($lineWidth > $maxWidth && $currentLine) {
            $lines[] = $currentLine;
            $currentLine = $word;
        } else {
            $currentLine = $testLine;
        }
    }
    
    if ($currentLine) {
        $lines[] = $currentLine;
    }
    
    return $lines;
}

/**
 * Load image from URL with error handling
 */
function loadImageFromUrl(string $url) {
    if (empty($url)) {
        return null;
    }
    
    // Set timeout for remote requests
    $context = stream_context_create([
        'http' => [
            'timeout' => 10,
            'user_agent' => 'FAHS-MAROC-Image-Loader/1.0'
        ]
    ]);
    
    $imageData = @file_get_contents($url, false, $context);
    
    if ($imageData === false) {
        return null;
    }
    
    $image = @imagecreatefromstring($imageData);
    
    return $image ?: null;
}

// =============================================================================
// ERROR HANDLING
// =============================================================================

/**
 * Display error as image
 */
function displayErrorImage(string $message): void {
    $image = imagecreatetruecolor(CANVAS_WIDTH, CANVAS_HEIGHT);
    
    // Background
    $bgColor = imagecolorallocate($image, 245, 247, 250);
    imagefill($image, 0, 0, $bgColor);
    
    // Error colors
    $redColor = imagecolorallocate($image, 231, 76, 60);
    $textColor = imagecolorallocate($image, 44, 62, 80);
    
    // Error icon (circle with X)
    $centerX = CANVAS_WIDTH / 2;
    $centerY = CANVAS_HEIGHT / 2 - 100;
    
    imagefilledellipse($image, $centerX, $centerY, 120, 120, $redColor);
    
    // X mark
    $white = imagecolorallocate($image, 255, 255, 255);
    imageline($image, $centerX - 30, $centerY - 30, $centerX + 30, $centerY + 30, $white);
    imageline($image, $centerX + 30, $centerY - 30, $centerX - 30, $centerY + 30, $white);
    
    // Error text
    $font = getFontPath('default');
    if ($font) {
        // Title
        $title = 'Error';
        $bbox = imagettfbbox(36, 0, $font, $title);
        $x = $centerX - ($bbox[2] - $bbox[0]) / 2;
        imagettftext($image, 36, 0, $x, $centerY + 100, $redColor, $font, $title);
        
        // Message
        $lines = wrapText($image, $font, 20, $message, CANVAS_WIDTH - 100);
        $y = $centerY + 160;
        foreach ($lines as $line) {
            $bbox = imagettfbbox(20, 0, $font, $line);
            $x = $centerX - ($bbox[2] - $bbox[0]) / 2;
            imagettftext($image, 20, 0, $x, $y, $textColor, $font, $line);
            $y += 35;
        }
    } else {
        imagestring($image, 5, $centerX - 50, $centerY + 100, 'ERROR', $redColor);
        imagestring($image, 3, $centerX - 100, $centerY + 140, $message, $textColor);
    }
    
    // Output
    header('Content-Type: image/png');
    imagepng($image);
    imagedestroy($image);
    exit;
}

// =============================================================================
// MAIN GENERATION LOGIC
// =============================================================================

try {
    // =========================================================================
    // SECURITY LAYER 2: Input Validation
    // =========================================================================
    
    $productId = isset($_GET['id']) ? filter_var($_GET['id'], FILTER_VALIDATE_INT) : 0;
    
    if ($productId === false || $productId <= 0) {
        displayErrorImage('Invalid product ID. Please provide a valid numeric ID.');
    }
    
    // =========================================================================
    // DATABASE FETCH WITH PDO PREPARED STATEMENTS
    // =========================================================================
    
    $db = getDBConnection();
    
    $stmt = $db->prepare("
        SELECT 
            p.*,
            c.name as category_name,
            c.id as category_id
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.id = :id
        LIMIT 1
    ");
    
    $stmt->execute([':id' => $productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        displayErrorImage('Product not found. The requested product ID does not exist.');
    }
    
    // =========================================================================
    // INITIALIZE CANVAS
    // =========================================================================
    
    $image = imagecreatetruecolor(CANVAS_WIDTH, CANVAS_HEIGHT);
    imageantialias($image, true);
    
    // Enable alpha channel
    imagealphablending($image, true);
    imagesavealpha($image, true);
    
    // =========================================================================
    // GET COLORS
    // =========================================================================
    
    $categoryColors = getCategoryColors((int)$product['category_id']);
    $scoreColors = getScoreColors($product['score'] !== null ? (int)$product['score'] : null);
    
    // =========================================================================
    // DRAW BACKGROUND
    // =========================================================================
    
    createGradientBackground($image, $categoryColors['primary'], $categoryColors['secondary']);
    
    // Add subtle pattern overlay
    $patternColor = imagecolorallocatealpha($image, 255, 255, 255, 110);
    for ($i = 0; $i < CANVAS_WIDTH; $i += 60) {
        imageline($image, $i, 0, $i, CANVAS_HEIGHT, $patternColor);
    }
    for ($i = 0; $i < CANVAS_HEIGHT; $i += 60) {
        imageline($image, 0, $i, CANVAS_WIDTH, $i, $patternColor);
    }
    
    // =========================================================================
    // DEFINE COMMON COLORS
    // =========================================================================
    
    $white = imagecolorallocate($image, 255, 255, 255);
    $black = imagecolorallocate($image, 0, 0, 0);
    $darkText = imagecolorallocate($image, 44, 62, 80);
    $lightText = imagecolorallocate($image, 127, 140, 141);
    $scoreBg = imagecolorallocate($image, $scoreColors['bg'][0], $scoreColors['bg'][1], $scoreColors['bg'][2]);
    $scoreText = imagecolorallocate($image, $scoreColors['text'][0], $scoreColors['text'][1], $scoreColors['text'][2]);
    
    // =========================================================================
    // LOAD FONTS
    // =========================================================================
    
    $defaultFont = getFontPath('default');
    $arabicFont = getFontPath('arabic');
    
    $hasTtfFonts = ($defaultFont !== null);
    
    // =========================================================================
    // DRAW VERTICAL INSTAGRAM HANDLE (Left Edge)
    // =========================================================================
    
    $handleStripWidth = 60;
    $handleStripColor = imagecolorallocatealpha($image, 0, 0, 0, 100);
    imagefilledrectangle($image, 0, 0, $handleStripWidth, CANVAS_HEIGHT, $handleStripColor);
    
    $handleText = '@fahs.maroc';
    
    if ($hasTtfFonts && function_exists('imagettftext')) {
        // Create temporary image for rotation
        $tempHeight = 400;
        $tempWidth = 50;
        $tempImg = imagecreatetruecolor($tempWidth, $tempHeight);
        imagefill($tempImg, 0, 0, imagecolorallocatealpha($tempImg, 0, 0, 0, 127));
        imagesavealpha($tempImg, true);
        
        imagettftext($tempImg, FONT_SIZE_HANDLE, 0, 10, 30, $white, $defaultFont, $handleText);
        
        // Rotate 90 degrees clockwise
        $rotated = imagerotate($tempImg, 270, imagecolorallocatealpha($image, 0, 0, 0, 127));
        
        // Position in center of strip
        $rotatedWidth = imagesx($rotated);
        $rotatedHeight = imagesy($rotated);
        $destY = (CANVAS_HEIGHT - $rotatedHeight) / 2;
        
        imagecopy($image, $rotated, 5, $destY, 0, 0, $rotatedWidth, $rotatedHeight);
        
        imagedestroy($tempImg);
        imagedestroy($rotated);
    } else {
        // Fallback to built-in font
        imagestring($image, 3, 15, CANVAS_HEIGHT / 2 - 40, '@fahs', $white);
        imagestring($image, 3, 15, CANVAS_HEIGHT / 2 - 10, '.maroc', $white);
    }
    
    // =========================================================================
    // DRAW HEADER SECTION (Logo + Tagline)
    // =========================================================================
    
    $headerY = 80;
    $logoSize = 80;
    $logoX = CANVAS_WIDTH / 2;
    
    // Load and draw logo
    if (file_exists(LOGO_PATH)) {
        $logoInfo = getimagesize(LOGO_PATH);
        $logoMime = $logoInfo['mime'] ?? '';
        
        $logoImage = null;
        if ($logoMime === 'image/png') {
            $logoImage = @imagecreatefrompng(LOGO_PATH);
        } elseif ($logoMime === 'image/jpeg' || $logoMime === 'image/jpg') {
            $logoImage = @imagecreatefromjpeg(LOGO_PATH);
        }
        
        if ($logoImage) {
            // Resize logo
            $logoResized = imagescale($logoImage, $logoSize, $logoSize);
            
            // Center the logo
            $destX = $logoX - $logoSize / 2;
            $destY = $headerY - $logoSize / 2;
            
            // Copy with alpha blending
            imagecopy($image, $logoResized, $destX, $destY, 0, 0, $logoSize, $logoSize);
            
            imagedestroy($logoImage);
            if ($logoResized !== $logoImage) {
                imagedestroy($logoResized);
            }
        } else {
            // Fallback: Draw circle with F
            imagefilledellipse($image, $logoX, $headerY, $logoSize, $logoSize, $white);
            $accentColor = imagecolorallocate($image, $categoryColors['accent'][0], $categoryColors['accent'][1], $categoryColors['accent'][2]);
            if ($hasTtfFonts) {
                imagettftext($image, 36, 0, $logoX - 15, $headerY + 12, $accentColor, $defaultFont, 'F');
            } else {
                imagestring($image, 5, $logoX - 8, $headerY - 8, 'F', $accentColor);
            }
        }
    } else {
        // Fallback: Draw circle with F
        imagefilledellipse($image, $logoX, $headerY, $logoSize, $logoSize, $white);
        $accentColor = imagecolorallocate($image, $categoryColors['accent'][0], $categoryColors['accent'][1], $categoryColors['accent'][2]);
        if ($hasTtfFonts) {
            imagettftext($image, 36, 0, $logoX - 15, $headerY + 12, $accentColor, $defaultFont, 'F');
        } else {
            imagestring($image, 5, $logoX - 8, $headerY - 8, 'F', $accentColor);
        }
    }
    
    // Draw Arabic tagline
    $taglineY = $headerY + 70;
    $tagline = 'دليلك للجودة والصحة';
    
    if ($hasTtfFonts && $arabicFont) {
        $bbox = imagettfbbox(FONT_SIZE_TAGLINE, 0, $arabicFont, $tagline);
        $taglineWidth = $bbox[2] - $bbox[0];
        $taglineX = (CANVAS_WIDTH - $taglineWidth) / 2;
        imagettftext($image, FONT_SIZE_TAGLINE, 0, $taglineX, $taglineY, $darkText, $arabicFont, $tagline);
    } elseif ($hasTtfFonts) {
        $bbox = imagettfbbox(FONT_SIZE_TAGLINE, 0, $defaultFont, 'FAHS MAROC');
        $taglineWidth = $bbox[2] - $bbox[0];
        $taglineX = (CANVAS_WIDTH - $taglineWidth) / 2;
        imagettftext($image, FONT_SIZE_TAGLINE, 0, $taglineX, $taglineY, $darkText, $defaultFont, 'FAHS MAROC');
    } else {
        imagestring($image, 4, CANVAS_WIDTH / 2 - 60, $taglineY - 10, 'FAHS MAROC', $darkText);
    }
    
    // =========================================================================
    // DRAW SCORE BADGE (Top Right)
    // =========================================================================
    
    $badgeX = CANVAS_WIDTH - 120;
    $badgeY = 140;
    $badgeRadius = 70;
    
    // Draw glow effect
    for ($i = 6; $i >= 0; $i--) {
        $glowAlpha = 80 + $i * 15;
        $glowColor = imagecolorallocatealpha($image, $scoreColors['bg'][0], $scoreColors['bg'][1], $scoreColors['bg'][2], $glowAlpha);
        imagefilledellipse($image, $badgeX, $badgeY, ($badgeRadius + $i * 3) * 2, ($badgeRadius + $i * 3) * 2, $glowColor);
    }
    
    // Draw badge circle
    imagefilledellipse($image, $badgeX, $badgeY, $badgeRadius * 2, $badgeRadius * 2, $white);
    
    // Draw score
    $score = $product['score'] ?? null;
    $scoreText = $score !== null ? (string)$score : 'N/A';
    
    if ($hasTtfFonts) {
        // Main score number
        $bbox = imagettfbbox(FONT_SIZE_SCORE, 0, $defaultFont, $scoreText);
        $scoreWidth = $bbox[2] - $bbox[0];
        imagettftext($image, FONT_SIZE_SCORE, 0, $badgeX - $scoreWidth / 2, $badgeY + 20, $scoreBg, $defaultFont, $scoreText);
        
        // /100 label
        $outOf = '/100';
        $bbox = imagettfbbox(FONT_SIZE_SCORE_LABEL, 0, $defaultFont, $outOf);
        $outOfWidth = $bbox[2] - $bbox[0];
        imagettftext($image, FONT_SIZE_SCORE_LABEL, 0, $badgeX - $outOfWidth / 2, $badgeY + 50, $lightText, $defaultFont, $outOf);
    } else {
        imagestring($image, 5, $badgeX - 25, $badgeY - 10, $scoreText, $scoreBg);
        imagestring($image, 2, $badgeX - 20, $badgeY + 20, '/100', $lightText);
    }
    
    // =========================================================================
    // DRAW PRODUCT IMAGE (Left Side with Shadow)
    // =========================================================================
    
    $imgX = 100;
    $imgY = 240;
    $imgWidth = 420;
    $imgHeight = 520;
    $imgRadius = 25;
    
    // Draw shadow
    drawShadow($image, $imgX, $imgY, $imgWidth, $imgHeight, $imgRadius, 40);
    
    // Draw image container
    $containerBg = imagecolorallocate($image, 255, 255, 255);
    drawRoundedRectangle($image, $imgX, $imgY, $imgWidth, $imgHeight, $imgRadius, $containerBg);
    
    // Load and draw product image
    $productImage = null;
    if (!empty($product['image_url'])) {
        $productImage = loadImageFromUrl($product['image_url']);
    }
    
    if ($productImage) {
        // Calculate aspect ratio and resize
        $origWidth = imagesx($productImage);
        $origHeight = imagesy($productImage);
        $aspectRatio = $origWidth / $origHeight;
        
        $fitWidth = $imgWidth - 40;
        $fitHeight = $imgHeight - 40;
        
        if ($fitWidth / $fitHeight > $aspectRatio) {
            $fitWidth = $fitHeight * $aspectRatio;
        } else {
            $fitHeight = $fitWidth / $aspectRatio;
        }
        
        // Resize
        $resizedImg = imagescale($productImage, (int)$fitWidth, (int)$fitHeight);
        
        // Center in container
        $destX = $imgX + ($imgWidth - $fitWidth) / 2;
        $destY = $imgY + ($imgHeight - $fitHeight) / 2;
        
        // Copy to main image
        imagecopy($image, $resizedImg, (int)$destX, (int)$destY, 0, 0, (int)$fitWidth, (int)$fitHeight);
        
        imagedestroy($productImage);
        imagedestroy($resizedImg);
    } else {
        // Placeholder
        $placeholderBg = imagecolorallocate($image, 236, 240, 241);
        $placeholderX = $imgX + 20;
        $placeholderY = $imgY + 20;
        $placeholderW = $imgWidth - 40;
        $placeholderH = $imgHeight - 40;
        
        drawRoundedRectangle($image, $placeholderX, $placeholderY, $placeholderW, $placeholderH, 15, $placeholderBg);
        
        if ($hasTtfFonts) {
            $msg = 'No Image';
            $bbox = imagettfbbox(24, 0, $defaultFont, $msg);
            $msgX = $imgX + ($imgWidth - ($bbox[2] - $bbox[0])) / 2;
            imagettftext($image, 24, 0, $msgX, $imgY + $imgHeight / 2, $lightText, $defaultFont, $msg);
        } else {
            imagestring($image, 4, $imgX + $imgWidth / 2 - 40, $imgY + $imgHeight / 2 - 10, 'No Image', $lightText);
        }
    }
    
    // Product name below image
    $nameY = $imgY + $imgHeight + 50;
    
    if ($hasTtfFonts) {
        $nameLines = wrapText($image, $defaultFont, FONT_SIZE_TITLE, $product['name'], $imgWidth);
        $lineY = $nameY;
        foreach ($nameLines as $line) {
            $bbox = imagettfbbox(FONT_SIZE_TITLE, 0, $defaultFont, $line);
            $lineWidth = $bbox[2] - $bbox[0];
            $lineX = $imgX + ($imgWidth - $lineWidth) / 2;
            imagettftext($image, FONT_SIZE_TITLE, 0, $lineX, $lineY, $white, $defaultFont, $line);
            $lineY += 45;
        }
        
        // Brand name
        if (!empty($product['brand'])) {
            $brand = $product['brand'];
            $bbox = imagettfbbox(FONT_SIZE_SUBTITLE, 0, $defaultFont, $brand);
            $brandWidth = $bbox[2] - $bbox[0];
            $brandX = $imgX + ($imgWidth - $brandWidth) / 2;
            imagettftext($image, FONT_SIZE_SUBTITLE, 0, $brandX, $lineY + 15, $lightText, $defaultFont, $brand);
        }
    } else {
        imagestring($image, 4, $imgX + 20, $nameY, substr($product['name'], 0, 35), $white);
        if (!empty($product['brand'])) {
            imagestring($image, 2, $imgX + 20, $nameY + 25, $product['brand'], $lightText);
        }
    }
    
    // =========================================================================
    // DRAW NUTRITIONAL ANALYSIS PANEL (Right Side)
    // =========================================================================
    
    $panelX = 580;
    $panelY = 240;
    $panelWidth = 460;
    $panelHeight = 580;
    $panelRadius = 20;
    
    // Draw panel shadow
    drawShadow($image, $panelX, $panelY, $panelWidth, $panelHeight, $panelRadius, 30);
    
    // Draw panel background
    $panelBg = imagecolorallocatealpha($image, 255, 255, 255, 25);
    drawRoundedRectangle($image, $panelX, $panelY, $panelWidth, $panelHeight, $panelRadius, $panelBg);
    
    // Panel title
    $titleY = $panelY + 50;
    
    if ($hasTtfFonts) {
        $title = 'Nutritional Analysis';
        imagettftext($image, FONT_SIZE_SECTION, 0, $panelX + 25, $titleY, $darkText, $defaultFont, $title);
    } else {
        imagestring($image, 4, $panelX + 25, $titleY - 15, 'Nutritional Analysis', $darkText);
    }
    
    // Divider line
    $dividerY = $titleY + 20;
    imageline($image, $panelX + 25, $dividerY, $panelX + $panelWidth - 25, $dividerY, $lightText);
    
    // =========================================================================
    // DRAW NUTRIENTS
    // =========================================================================
    
    $nutrientY = $dividerY + 50;
    $nutrientHeight = 65;
    
    $nutrients = [
        ['key' => 'protein',       'label' => 'Protein',       'unit' => 'g'],
        ['key' => 'calories',      'label' => 'Calories',      'unit' => 'kcal'],
        ['key' => 'sugar',         'label' => 'Sugar',         'unit' => 'g'],
        ['key' => 'salt',          'label' => 'Salt',          'unit' => 'g'],
        ['key' => 'saturated_fat', 'label' => 'Saturated Fat', 'unit' => 'g'],
    ];
    
    foreach ($nutrients as $nutrient) {
        $value = $product[$nutrient['key']] ?? null;
        $displayValue = $value !== null ? number_format((float)$value, 1) : 'N/A';
        
        // Get health indicator color
        $healthColor = getNutrientHealthColor($nutrient['key'], $value !== null ? (float)$value : null);
        $indicatorColor = imagecolorallocate($image, $healthColor['r'], $healthColor['g'], $healthColor['b']);
        
        // Icon circle background
        $iconBg = imagecolorallocatealpha($image, 255, 255, 255, 50);
        imagefilledellipse($image, $panelX + 50, $nutrientY + 15, 45, 45, $iconBg);
        
        // First letter of nutrient as icon
        if ($hasTtfFonts) {
            $icon = strtoupper(substr($nutrient['label'], 0, 1));
            imagettftext($image, 18, 0, $panelX + 43, $nutrientY + 22, $darkText, $defaultFont, $icon);
            
            // Label
            imagettftext($image, FONT_SIZE_NUTRIENT_LABEL, 0, $panelX + 80, $nutrientY + 5, $darkText, $defaultFont, $nutrient['label']);
            
            // Value
            $valueText = $displayValue . ' ' . $nutrient['unit'];
            imagettftext($image, FONT_SIZE_NUTRIENT_VALUE, 0, $panelX + 80, $nutrientY + 35, $lightText, $defaultFont, $valueText);
        } else {
            imagestring($image, 3, $panelX + 40, $nutrientY + 5, strtoupper(substr($nutrient['label'], 0, 1)), $darkText);
            imagestring($image, 3, $panelX + 80, $nutrientY, $nutrient['label'], $darkText);
            imagestring($image, 4, $panelX + 80, $nutrientY + 18, $displayValue . ' ' . $nutrient['unit'], $lightText);
        }
        
        // Health indicator dot
        imagefilledellipse($image, $panelX + $panelWidth - 40, $nutrientY + 15, 22, 22, $indicatorColor);
        
        $nutrientY += $nutrientHeight;
    }
    
    // =========================================================================
    // DRAW POSITIVES / NEGATIVES SECTION
    // =========================================================================
    
    $summaryY = $nutrientY + 20;
    
    if (!empty($product['additives_status'])) {
        $isPositive = stripos($product['additives_status'], 'No') !== false;
        $statusBg = imagecolorallocatealpha($image, 255, 255, 255, 40);
        
        drawRoundedRectangle($image, $panelX + 15, $summaryY - 10, $panelWidth - 30, 55, 12, $statusBg);
        
        $statusColor = $isPositive 
            ? imagecolorallocate($image, 46, 204, 113)  // Green
            : imagecolorallocate($image, 231, 76, 60);   // Red
        
        // Checkmark or X circle
        imagefilledellipse($image, $panelX + 45, $summaryY + 17, 35, 35, $statusColor);
        
        if ($hasTtfFonts) {
            $icon = $isPositive ? '✓' : '✗';
            imagettftext($image, 22, 0, $panelX + 37, $summaryY + 25, $white, $defaultFont, $icon);
            imagettftext($image, 20, 0, $panelX + 70, $summaryY + 25, $darkText, $defaultFont, $product['additives_status']);
        } else {
            imagestring($image, 4, $panelX + 70, $summaryY + 5, $product['additives_status'], $isPositive ? $statusColor : $statusColor);
        }
    }
    
    // =========================================================================
    // DRAW CATEGORY BADGE (Footer)
    // =========================================================================
    
    $footerY = CANVAS_HEIGHT - 70;
    $categoryName = $product['category_name'] ?? 'Uncategorized';
    
    if ($hasTtfFonts) {
        $bbox = imagettfbbox(18, 0, $defaultFont, $categoryName);
        $badgeWidth = $bbox[2] - $bbox[0] + 50;
        $badgeX = (CANVAS_WIDTH - $badgeWidth) / 2;
        
        $badgeBg = imagecolorallocatealpha($image, 255, 255, 255, 40);
        drawRoundedRectangle($image, (int)$badgeX, $footerY - 15, (int)$badgeWidth, 45, 22, $badgeBg);
        
        imagettftext($image, 18, 0, (int)($badgeX + 25), $footerY + 12, $white, $defaultFont, $categoryName);
    } else {
        imagestring($image, 3, CANVAS_WIDTH / 2 - 60, $footerY, $categoryName, $white);
    }
    
    // =========================================================================
    // OUTPUT IMAGE
    // =========================================================================
    
    // Clean output buffers
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Generate filename
    $safeName = preg_replace('/[^a-zA-Z0-9]/', '_', strtolower($product['name']));
    $filename = 'fahs_' . $safeName . '_instagram.png';
    
    // Set headers for download
    header('Content-Type: image/png');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');
    
    // Output
    imagepng($image);
    
    // Cleanup
    imagedestroy($image);
    exit;
    
} catch (Exception $e) {
    // Log error (don't expose details)
    error_log('Instagram Export Error: ' . $e->getMessage());
    displayErrorImage('An error occurred while generating the image. Please try again.');
}
