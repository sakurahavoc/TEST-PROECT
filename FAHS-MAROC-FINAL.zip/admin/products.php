<?php
/**
 * FAHS MAROC - All Products Listing
 * View, search, and manage all products
 */
$pageTitle = 'All Products';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth_check.php';

$db = getDBConnection();

// Handle delete action
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    if (!verifyCSRFToken($_GET['token'] ?? '')) {
        setFlashMessage('error', 'Invalid request.');
    } else {
        $id = (int)$_GET['id'];
        try {
            $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            setFlashMessage('success', 'Product deleted successfully.');
        } catch (PDOException $e) {
            setFlashMessage('error', 'Error deleting product.');
        }
    }
    redirect(APP_URL . '/admin/products.php');
}

// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Search filter
$search = trim($_GET['search'] ?? '');
$categoryFilter = (int)($_GET['category'] ?? 0);

// Build query
$whereClauses = [];
$params = [];

if ($search) {
    $whereClauses[] = "(p.name LIKE ? OR p.brand LIKE ? OR p.description LIKE ?)";
    $searchParam = "%$search%";
    $params = array_merge($params, [$searchParam, $searchParam, $searchParam]);
}

if ($categoryFilter > 0) {
    $whereClauses[] = "p.category_id = ?";
    $params[] = $categoryFilter;
}

$whereSql = $whereClauses ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

// Get total count
$countStmt = $db->prepare("SELECT COUNT(*) as count FROM products p $whereSql");
$countStmt->execute($params);
$totalProducts = $countStmt->fetch()['count'];
$totalPages = ceil($totalProducts / $perPage);

// Get products
$query = "SELECT p.*, c.name as category_name 
          FROM products p 
          LEFT JOIN categories c ON p.category_id = c.id 
          $whereSql 
          ORDER BY p.created_at DESC 
          LIMIT ? OFFSET ?";
$stmt = $db->prepare($query);
$stmt->execute(array_merge($params, [$perPage, $offset]));
$products = $stmt->fetchAll();

// Get categories for filter
$catStmt = $db->query("SELECT id, name FROM categories ORDER BY name ASC");
$categories = $catStmt->fetchAll();

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        fahs: {
                            green: '#2D5A27',
                            'green-light': '#4A7C43',
                            'green-dark': '#1E3D1A',
                        }
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex">
        
        <!-- Sidebar -->
        <aside class="w-64 bg-fahs-green-dark text-white flex-shrink-0">
            <div class="p-6">
                <div class="flex items-center space-x-2">
                    <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                        <span class="text-fahs-green font-bold text-lg">F</span>
                    </div>
                    <span class="font-bold text-lg">FAHS Admin</span>
                </div>
            </div>
            
            <nav class="mt-6">
                <a href="dashboard.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
                    </svg>
                    Dashboard
                </a>
                <a href="categories.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
                    </svg>
                    Categories
                </a>
                <a href="add_product.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    Add Product
                </a>
                <a href="products.php" class="flex items-center px-6 py-3 bg-fahs-green border-l-4 border-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                    </svg>
                    All Products
                </a>
            </nav>
            
            <div class="absolute bottom-0 w-64 p-6">
                <a href="logout.php" class="flex items-center text-green-200 hover:text-white transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Logout
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="flex-1 p-8">
            <div class="max-w-6xl">
                <h1 class="text-3xl font-bold text-gray-800 mb-2">All Products</h1>
                <p class="text-gray-600 mb-8">Manage your product catalog</p>
                
                <!-- Flash Messages -->
                <?php $flash = getFlashMessage(); if ($flash): ?>
                    <div class="mb-6 rounded-lg p-4 <?php 
                        echo $flash['type'] === 'success' 
                            ? 'bg-green-100 text-green-800 border border-green-200' 
                            : 'bg-red-100 text-red-800 border border-red-200';
                    ?>">
                        <?php echo sanitize($flash['message']); ?>
                    </div>
                <?php endif; ?>
                
                <!-- Search & Filter -->
                <div class="bg-white rounded-xl shadow-md p-6 mb-6">
                    <form method="GET" action="" class="flex flex-wrap gap-4">
                        <div class="flex-1 min-w-[200px]">
                            <input type="text" 
                                   name="search" 
                                   placeholder="Search products..."
                                   value="<?php echo sanitize($search); ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent">
                        </div>
                        <div class="w-48">
                            <select name="category" 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>" <?php echo $categoryFilter == $cat['id'] ? 'selected' : ''; ?>>
                                        <?php echo sanitize($cat['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="px-6 py-3 bg-fahs-green text-white rounded-lg hover:bg-fahs-green-dark transition-colors">
                            Search
                        </button>
                        <?php if ($search || $categoryFilter): ?>
                            <a href="products.php" class="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors">
                                Clear
                            </a>
                        <?php endif; ?>
                    </form>
                </div>
                
                <!-- Products Table -->
                <div class="bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                        <h2 class="text-lg font-semibold text-gray-800">
                            Products (<?php echo number_format($totalProducts); ?>)
                        </h2>
                        <a href="add_product.php" class="px-4 py-2 bg-fahs-green text-white rounded-lg hover:bg-fahs-green-dark transition-colors text-sm">
                            + Add Product
                        </a>
                    </div>
                    
                    <?php if (!empty($products)): ?>
                        <div class="overflow-x-auto">
                            <table class="w-full">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Brand</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Score</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nutrition</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php foreach ($products as $product): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="px-6 py-4">
                                                <div class="flex items-center">
                                                    <div class="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center mr-3 overflow-hidden flex-shrink-0">
                                                        <?php if ($product['image_url']): ?>
                                                            <img src="<?php echo sanitize($product['image_url']); ?>" alt="" class="w-full h-full object-cover">
                                                        <?php else: ?>
                                                            <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                                            </svg>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div>
                                                        <div class="font-medium text-gray-900"><?php echo sanitize($product['name']); ?></div>
                                                        <?php if ($product['additives_status']): ?>
                                                            <div class="text-xs text-gray-500"><?php echo sanitize($product['additives_status']); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 text-gray-600"><?php echo sanitize($product['category_name'] ?? 'N/A'); ?></td>
                                            <td class="px-6 py-4 text-gray-600"><?php echo sanitize($product['brand'] ?? 'N/A'); ?></td>
                                            <td class="px-6 py-4">
                                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium <?php 
                                                    $score = $product['score'];
                                                    echo $score >= 80 ? 'bg-green-100 text-green-800' : 
                                                         ($score >= 60 ? 'bg-yellow-100 text-yellow-800' : 
                                                         ($score >= 40 ? 'bg-orange-100 text-orange-800' : 'bg-red-100 text-red-800'));
                                                ?>">
                                                    <?php echo $score ?? 'N/A'; ?>/100
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 text-sm text-gray-600">
                                                <div class="space-y-1">
                                                    <?php if ($product['calories']): ?>
                                                        <div><?php echo $product['calories']; ?> kcal</div>
                                                    <?php endif; ?>
                                                    <?php if ($product['protein']): ?>
                                                        <div class="text-gray-400"><?php echo $product['protein']; ?>g protein</div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4">
                                                <div class="flex space-x-3">
                                                    <a href="edit_product.php?id=<?php echo $product['id']; ?>" 
                                                       class="text-blue-600 hover:text-blue-800 text-sm font-medium"
                                                       title="Edit Product">
                                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                                        </svg>
                                                    </a>
                                                    <a href="export_insta.php?id=<?php echo $product['id']; ?>" 
                                                       class="text-pink-600 hover:text-pink-800 text-sm font-medium"
                                                       title="Export Instagram Image"
                                                       target="_blank">
                                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                                        </svg>
                                                    </a>
                                                    <a href="?action=delete&id=<?php echo $product['id']; ?>&token=<?php echo $csrfToken; ?>" 
                                                       class="text-red-600 hover:text-red-800 text-sm font-medium"
                                                       onclick="return confirm('Delete \"<?php echo sanitize($product['name']); ?>\"?')"
                                                       title="Delete Product">
                                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                                        </svg>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($totalPages > 1): ?>
                            <div class="px-6 py-4 border-t border-gray-200 flex justify-between items-center">
                                <p class="text-sm text-gray-600">
                                    Showing <?php echo (($page - 1) * $perPage) + 1; ?> - <?php echo min($page * $perPage, $totalProducts); ?> of <?php echo $totalProducts; ?>
                                </p>
                                <div class="flex space-x-2">
                                    <?php if ($page > 1): ?>
                                        <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $categoryFilter; ?>" 
                                           class="px-3 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors">
                                            Previous
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($page < $totalPages): ?>
                                        <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $categoryFilter; ?>" 
                                           class="px-3 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors">
                                            Next
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="p-12 text-center text-gray-500">
                            <svg class="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                            </svg>
                            <p class="text-lg">No products found.</p>
                            <?php if ($search || $categoryFilter): ?>
                                <a href="products.php" class="text-fahs-green hover:underline mt-2 inline-block">Clear filters</a>
                            <?php else: ?>
                                <a href="add_product.php" class="text-fahs-green hover:underline mt-2 inline-block">Add your first product</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
