<?php
/**
 * FAHS MAROC - Category Management
 * Add, view, and delete product categories
 */
$pageTitle = 'Manage Categories';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth_check.php';

$db = getDBConnection();
$message = '';
$error = '';

// Handle Add Category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $name = trim($_POST['name'] ?? '');
        
        if (empty($name)) {
            $error = 'Category name is required.';
        } elseif (strlen($name) > 100) {
            $error = 'Category name must be less than 100 characters.';
        } else {
            try {
                $stmt = $db->prepare("INSERT INTO categories (name) VALUES (?)");
                $stmt->execute([$name]);
                setFlashMessage('success', 'Category "' . sanitize($name) . '" added successfully!');
                redirect(APP_URL . '/admin/categories.php');
            } catch (PDOException $e) {
                if ($e->getCode() == 23000) {
                    $error = 'A category with this name already exists.';
                } else {
                    $error = 'Error adding category. Please try again.';
                }
            }
        }
    }
}

// Handle Delete Category
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    if (!verifyCSRFToken($_GET['token'] ?? '')) {
        setFlashMessage('error', 'Invalid request. Please try again.');
    } else {
        $id = (int)$_GET['id'];
        
        try {
            // Check if category has products
            $checkStmt = $db->prepare("SELECT COUNT(*) as count FROM products WHERE category_id = ?");
            $checkStmt->execute([$id]);
            $productCount = $checkStmt->fetch()['count'];
            
            if ($productCount > 0) {
                setFlashMessage('error', 'Cannot delete category: It contains ' . $productCount . ' product(s). Please reassign or delete products first.');
            } else {
                $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
                $stmt->execute([$id]);
                setFlashMessage('success', 'Category deleted successfully!');
            }
        } catch (PDOException $e) {
            setFlashMessage('error', 'Error deleting category. Please try again.');
        }
    }
    redirect(APP_URL . '/admin/categories.php');
}

// Fetch all categories with product count
$stmt = $db->query("SELECT c.*, COUNT(p.id) as product_count 
                    FROM categories c 
                    LEFT JOIN products p ON c.id = p.category_id 
                    GROUP BY c.id 
                    ORDER BY c.name ASC");
$categories = $stmt->fetchAll();

// Get CSRF token for delete links
$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        fahs: {
                            green: '#2D5A27',
                            'green-light': '#4A7C43',
                            'green-dark': '#1E3D1A',
                        }
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex">
        
        <!-- Sidebar -->
        <aside class="w-64 bg-fahs-green-dark text-white flex-shrink-0">
            <div class="p-6">
                <div class="flex items-center space-x-2">
                    <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                        <span class="text-fahs-green font-bold text-lg">F</span>
                    </div>
                    <span class="font-bold text-lg">FAHS Admin</span>
                </div>
            </div>
            
            <nav class="mt-6">
                <a href="dashboard.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
                    </svg>
                    Dashboard
                </a>
                <a href="categories.php" class="flex items-center px-6 py-3 bg-fahs-green border-l-4 border-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
                    </svg>
                    Categories
                </a>
                <a href="add_product.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    Add Product
                </a>
                <a href="products.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                    </svg>
                    All Products
                </a>
            </nav>
            
            <div class="absolute bottom-0 w-64 p-6">
                <a href="logout.php" class="flex items-center text-green-200 hover:text-white transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Logout
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="flex-1 p-8">
            <div class="max-w-4xl">
                <h1 class="text-3xl font-bold text-gray-800 mb-2">Manage Categories</h1>
                <p class="text-gray-600 mb-8">Add and organize product categories</p>
                
                <!-- Flash Messages -->
                <?php $flash = getFlashMessage(); if ($flash): ?>
                    <div class="mb-6 rounded-lg p-4 <?php 
                        echo $flash['type'] === 'success' 
                            ? 'bg-green-100 text-green-800 border border-green-200' 
                            : 'bg-red-100 text-red-800 border border-red-200';
                    ?>">
                        <?php echo sanitize($flash['message']); ?>
                    </div>
                <?php endif; ?>
                
                <!-- Error Message -->
                <?php if ($error): ?>
                    <div class="mb-6 bg-red-100 border border-red-200 text-red-800 rounded-lg p-4">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Add Category Form -->
                <div class="bg-white rounded-xl shadow-md p-6 mb-8">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">Add New Category</h2>
                    <form method="POST" action="" class="flex gap-4">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="flex-1">
                            <input type="text" 
                                   name="name" 
                                   required 
                                   maxlength="100"
                                   placeholder="Enter category name (e.g., Dairy Products)"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                   value="<?php echo isset($_POST['name']) ? sanitize($_POST['name']) : ''; ?>">
                        </div>
                        <button type="submit" 
                                class="px-6 py-3 bg-fahs-green text-white rounded-lg font-medium hover:bg-fahs-green-dark transition-colors flex items-center">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                            </svg>
                            Add Category
                        </button>
                    </form>
                </div>
                
                <!-- Categories Table -->
                <div class="bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h2 class="text-xl font-semibold text-gray-800">Existing Categories</h2>
                    </div>
                    
                    <?php if (!empty($categories)): ?>
                        <table class="w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category Name</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Products</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <?php foreach ($categories as $category): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-6 py-4 text-gray-600">#<?php echo $category['id']; ?></td>
                                        <td class="px-6 py-4 font-medium text-gray-900">
                                            <?php echo sanitize($category['name']); ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium <?php 
                                                echo $category['product_count'] > 0 ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-600';
                                            ?>">
                                                <?php echo $category['product_count']; ?> product<?php echo $category['product_count'] !== 1 ? 's' : ''; ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-gray-500 text-sm">
                                            <?php echo date('M d, Y', strtotime($category['created_at'])); ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <a href="?action=delete&id=<?php echo $category['id']; ?>&token=<?php echo $csrfToken; ?>" 
                                               class="text-red-600 hover:text-red-800 text-sm font-medium"
                                               onclick="return confirm('Are you sure you want to delete \"<?php echo sanitize($category['name']); ?>\"?')">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="p-8 text-center text-gray-500">
                            <svg class="w-12 h-12 text-gray-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
                            </svg>
                            <p>No categories yet. Add your first category above!</p>
                        </div>
                    <?php endif; ?>
                </div>
                
            </div>
        </main>
    </div>
</body>
</html>
