<?php
/**
 * FAHS MAROC - Add Product
 * Form to add new products to the database
 */
$pageTitle = 'Add Product';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth_check.php';

$db = getDBConnection();
$error = '';
$success = '';

// Fetch categories for dropdown
$catStmt = $db->query("SELECT id, name FROM categories ORDER BY name ASC");
$categories = $catStmt->fetchAll();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Validate required fields
        $category_id = (int)($_POST['category_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        
        if ($category_id <= 0) {
            $error = 'Please select a category.';
        } elseif (empty($name)) {
            $error = 'Product name is required.';
        } elseif (strlen($name) > 255) {
            $error = 'Product name must be less than 255 characters.';
        } else {
            // Sanitize and prepare data
            $brand = trim($_POST['brand'] ?? '') ?: null;
            $score = $_POST['score'] !== '' ? (int)$_POST['score'] : null;
            $additives_status = trim($_POST['additives_status'] ?? '') ?: null;
            $protein = $_POST['protein'] !== '' ? (float)$_POST['protein'] : null;
            $calories = $_POST['calories'] !== '' ? (float)$_POST['calories'] : null;
            $sugar = $_POST['sugar'] !== '' ? (float)$_POST['sugar'] : null;
            $salt = $_POST['salt'] !== '' ? (float)$_POST['salt'] : null;
            $saturated_fat = $_POST['saturated_fat'] !== '' ? (float)$_POST['saturated_fat'] : null;
            $description = trim($_POST['description'] ?? '') ?: null;
            $image_url = trim($_POST['image_url'] ?? '') ?: null;
            
            // Validate score range
            if ($score !== null && ($score < 0 || $score > 100)) {
                $error = 'Score must be between 0 and 100.';
            } else {
                try {
                    $stmt = $db->prepare("INSERT INTO products 
                        (category_id, name, brand, score, additives_status, protein, calories, sugar, salt, saturated_fat, description, image_url) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    
                    $stmt->execute([
                        $category_id, $name, $brand, $score, $additives_status,
                        $protein, $calories, $sugar, $salt, $saturated_fat,
                        $description, $image_url
                    ]);
                    
                    setFlashMessage('success', 'Product "' . sanitize($name) . '" added successfully!');
                    redirect(APP_URL . '/admin/add_product.php');
                    
                } catch (PDOException $e) {
                    $error = 'Error adding product. Please try again.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        fahs: {
                            green: '#2D5A27',
                            'green-light': '#4A7C43',
                            'green-dark': '#1E3D1A',
                        }
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex">
        
        <!-- Sidebar -->
        <aside class="w-64 bg-fahs-green-dark text-white flex-shrink-0">
            <div class="p-6">
                <div class="flex items-center space-x-2">
                    <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                        <span class="text-fahs-green font-bold text-lg">F</span>
                    </div>
                    <span class="font-bold text-lg">FAHS Admin</span>
                </div>
            </div>
            
            <nav class="mt-6">
                <a href="dashboard.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
                    </svg>
                    Dashboard
                </a>
                <a href="categories.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
                    </svg>
                    Categories
                </a>
                <a href="add_product.php" class="flex items-center px-6 py-3 bg-fahs-green border-l-4 border-white">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    Add Product
                </a>
                <a href="products.php" class="flex items-center px-6 py-3 hover:bg-fahs-green transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                    </svg>
                    All Products
                </a>
            </nav>
            
            <div class="absolute bottom-0 w-64 p-6">
                <a href="logout.php" class="flex items-center text-green-200 hover:text-white transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Logout
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="flex-1 p-8">
            <div class="max-w-4xl">
                <h1 class="text-3xl font-bold text-gray-800 mb-2">Add New Product</h1>
                <p class="text-gray-600 mb-8">Enter product details and nutritional information</p>
                
                <!-- Flash Messages -->
                <?php $flash = getFlashMessage(); if ($flash): ?>
                    <div class="mb-6 rounded-lg p-4 <?php 
                        echo $flash['type'] === 'success' 
                            ? 'bg-green-100 text-green-800 border border-green-200' 
                            : 'bg-red-100 text-red-800 border border-red-200';
                    ?>">
                        <?php echo sanitize($flash['message']); ?>
                    </div>
                <?php endif; ?>
                
                <!-- Error Message -->
                <?php if ($error): ?>
                    <div class="mb-6 bg-red-100 border border-red-200 text-red-800 rounded-lg p-4">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Product Form -->
                <form method="POST" action="" class="bg-white rounded-xl shadow-md p-8">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    
                    <!-- Basic Information -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Basic Information</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Category -->
                            <div>
                                <label for="category_id" class="block text-sm font-medium text-gray-700 mb-2">
                                    Category <span class="text-red-500">*</span>
                                </label>
                                <select name="category_id" 
                                        id="category_id" 
                                        required
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent">
                                    <option value="">-- Select Category --</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?php echo $cat['id']; ?>" <?php echo (isset($_POST['category_id']) && $_POST['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
                                            <?php echo sanitize($cat['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (empty($categories)): ?>
                                    <p class="text-orange-600 text-sm mt-1">
                                        No categories found. <a href="categories.php" class="underline">Create one first</a>.
                                    </p>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Product Name -->
                            <div>
                                <label for="name" class="block text-sm font-medium text-gray-700 mb-2">
                                    Product Name <span class="text-red-500">*</span>
                                </label>
                                <input type="text" 
                                       name="name" 
                                       id="name" 
                                       required
                                       maxlength="255"
                                       placeholder="e.g., Fresh Whole Milk"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['name']) ? sanitize($_POST['name']) : ''; ?>">
                            </div>
                            
                            <!-- Brand -->
                            <div>
                                <label for="brand" class="block text-sm font-medium text-gray-700 mb-2">
                                    Brand
                                </label>
                                <input type="text" 
                                       name="brand" 
                                       id="brand" 
                                       maxlength="100"
                                       placeholder="e.g., Centrale Laitière"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['brand']) ? sanitize($_POST['brand']) : ''; ?>">
                            </div>
                            
                            <!-- Health Score -->
                            <div>
                                <label for="score" class="block text-sm font-medium text-gray-700 mb-2">
                                    Health Score (0-100)
                                </label>
                                <input type="number" 
                                       name="score" 
                                       id="score" 
                                       min="0" 
                                       max="100"
                                       placeholder="e.g., 85"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['score']) ? sanitize($_POST['score']) : ''; ?>">
                                <p class="text-gray-500 text-xs mt-1">Higher is better (80+ = Excellent)</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Nutritional Information -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Nutritional Information (per 100g)</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <!-- Protein -->
                            <div>
                                <label for="protein" class="block text-sm font-medium text-gray-700 mb-2">
                                    Protein (g)
                                </label>
                                <input type="number" 
                                       name="protein" 
                                       id="protein" 
                                       step="0.01"
                                       min="0"
                                       placeholder="e.g., 3.20"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['protein']) ? sanitize($_POST['protein']) : ''; ?>">
                            </div>
                            
                            <!-- Calories -->
                            <div>
                                <label for="calories" class="block text-sm font-medium text-gray-700 mb-2">
                                    Calories (kcal)
                                </label>
                                <input type="number" 
                                       name="calories" 
                                       id="calories" 
                                       step="0.01"
                                       min="0"
                                       placeholder="e.g., 64.00"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['calories']) ? sanitize($_POST['calories']) : ''; ?>">
                            </div>
                            
                            <!-- Sugar -->
                            <div>
                                <label for="sugar" class="block text-sm font-medium text-gray-700 mb-2">
                                    Sugar (g)
                                </label>
                                <input type="number" 
                                       name="sugar" 
                                       id="sugar" 
                                       step="0.01"
                                       min="0"
                                       placeholder="e.g., 4.80"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['sugar']) ? sanitize($_POST['sugar']) : ''; ?>">
                            </div>
                            
                            <!-- Salt -->
                            <div>
                                <label for="salt" class="block text-sm font-medium text-gray-700 mb-2">
                                    Salt (g)
                                </label>
                                <input type="number" 
                                       name="salt" 
                                       id="salt" 
                                       step="0.01"
                                       min="0"
                                       placeholder="e.g., 0.10"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['salt']) ? sanitize($_POST['salt']) : ''; ?>">
                            </div>
                            
                            <!-- Saturated Fat -->
                            <div>
                                <label for="saturated_fat" class="block text-sm font-medium text-gray-700 mb-2">
                                    Saturated Fat (g)
                                </label>
                                <input type="number" 
                                       name="saturated_fat" 
                                       id="saturated_fat" 
                                       step="0.01"
                                       min="0"
                                       placeholder="e.g., 2.50"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['saturated_fat']) ? sanitize($_POST['saturated_fat']) : ''; ?>">
                            </div>
                            
                            <!-- Additives Status -->
                            <div>
                                <label for="additives_status" class="block text-sm font-medium text-gray-700 mb-2">
                                    Additives Status
                                </label>
                                <select name="additives_status" 
                                        id="additives_status"
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent">
                                    <option value="">-- Select --</option>
                                    <option value="No Additives" <?php echo (isset($_POST['additives_status']) && $_POST['additives_status'] === 'No Additives') ? 'selected' : ''; ?>>No Additives</option>
                                    <option value="Contains Additives" <?php echo (isset($_POST['additives_status']) && $_POST['additives_status'] === 'Contains Additives') ? 'selected' : ''; ?>>Contains Additives</option>
                                    <option value="Natural Additives Only" <?php echo (isset($_POST['additives_status']) && $_POST['additives_status'] === 'Natural Additives Only') ? 'selected' : ''; ?>>Natural Additives Only</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Additional Information -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Additional Information</h2>
                        
                        <div class="space-y-6">
                            <!-- Image URL -->
                            <div>
                                <label for="image_url" class="block text-sm font-medium text-gray-700 mb-2">
                                    Product Image URL
                                </label>
                                <input type="url" 
                                       name="image_url" 
                                       id="image_url" 
                                       placeholder="https://github.com/yourname/images/raw/main/product.jpg"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent"
                                       value="<?php echo isset($_POST['image_url']) ? sanitize($_POST['image_url']) : ''; ?>">
                                <p class="text-gray-500 text-xs mt-1">
                                    Paste direct link from GitHub, MediaFire, or any image hosting service
                                </p>
                            </div>
                            
                            <!-- Description -->
                            <div>
                                <label for="description" class="block text-sm font-medium text-gray-700 mb-2">
                                    Product Description
                                </label>
                                <textarea name="description" 
                                          id="description" 
                                          rows="4"
                                          placeholder="Enter product description, ingredients, or any additional information..."
                                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fahs-green focus:border-transparent resize-vertical"><?php echo isset($_POST['description']) ? sanitize($_POST['description']) : ''; ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Submit Buttons -->
                    <div class="flex gap-4 pt-4 border-t">
                        <button type="submit" 
                                class="px-8 py-3 bg-fahs-green text-white rounded-lg font-medium hover:bg-fahs-green-dark transition-colors flex items-center">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                            </svg>
                            Add Product
                        </button>
                        <a href="products.php" 
                           class="px-8 py-3 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 transition-colors">
                            Cancel
                        </a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
