-- =====================================================
-- FAHS MAROC - Database Schema
-- Health & Quality Product Directory
-- =====================================================

-- Create Database (if not exists)
CREATE DATABASE IF NOT EXISTS fahs_maroc 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE fahs_maroc;

-- =====================================================
-- Table: categories
-- Product categories for organization
-- =====================================================
CREATE TABLE IF NOT EXISTS categories (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_category_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Table: products
-- Main product catalog with nutritional information
-- =====================================================
CREATE TABLE IF NOT EXISTS products (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    category_id INT(11) UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    brand VARCHAR(100) DEFAULT NULL,
    score INT(3) UNSIGNED DEFAULT NULL COMMENT 'Health score 0-100',
    additives_status VARCHAR(50) DEFAULT NULL COMMENT 'e.g., No Additives, Contains Additives',
    protein DECIMAL(6,2) UNSIGNED DEFAULT NULL COMMENT 'per 100g',
    calories DECIMAL(6,2) UNSIGNED DEFAULT NULL COMMENT 'kcal per 100g',
    sugar DECIMAL(6,2) UNSIGNED DEFAULT NULL COMMENT 'g per 100g',
    salt DECIMAL(6,2) UNSIGNED DEFAULT NULL COMMENT 'g per 100g',
    saturated_fat DECIMAL(6,2) UNSIGNED DEFAULT NULL COMMENT 'g per 100g',
    description TEXT DEFAULT NULL,
    image_url TEXT DEFAULT NULL COMMENT 'External image URL (GitHub/MediaFire)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_category_id (category_id),
    KEY idx_score (score),
    KEY idx_brand (brand),
    FULLTEXT KEY ft_name_description (name, description),
    CONSTRAINT fk_product_category 
        FOREIGN KEY (category_id) 
        REFERENCES categories(id) 
        ON DELETE RESTRICT 
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Table: admins
-- Administrator accounts for backend management
-- =====================================================
CREATE TABLE IF NOT EXISTS admins (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL COMMENT 'Bcrypt hashed password',
    email VARCHAR(100) DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    is_active TINYINT(1) UNSIGNED DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username),
    UNIQUE KEY uk_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Sample Data (Optional - for testing)
-- =====================================================

-- Sample Categories
INSERT INTO categories (name) VALUES 
    ('Dairy Products'),
    ('Beverages'),
    ('Snacks'),
    ('Breakfast Cereals'),
    ('Oils & Fats'),
    ('Baby Food'),
    ('Bakery'),
    ('Frozen Foods');

-- Sample Admin (password: 'admin123' - change in production!)
-- Hash generated with: password_hash('admin123', PASSWORD_BCRYPT)
INSERT INTO admins (username, password, email) VALUES 
    ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@fahsmaroc.ma');

-- Sample Products
INSERT INTO products (category_id, name, brand, score, additives_status, protein, calories, sugar, salt, saturated_fat, description, image_url) VALUES
    (1, 'Fresh Whole Milk', 'Centrale Laitière', 85, 'No Additives', 3.20, 64.00, 4.80, 0.10, 2.50, 'Fresh pasteurized whole milk from Moroccan dairy farms.', 'https://github.com/fahsmaroc/images/raw/main/milk.jpg'),
    (2, 'Natural Orange Juice', 'Les Domaines Agricoles', 90, 'No Additives', 0.70, 45.00, 8.50, 0.01, 0.00, '100% natural orange juice, no added sugars or preservatives.', 'https://github.com/fahsmaroc/images/raw/main/orange-juice.jpg'),
    (3, 'Whole Wheat Bread', 'Pain Quotidien', 78, 'No Additives', 9.00, 247.00, 3.50, 1.20, 0.80, 'Traditional Moroccan whole wheat bread, baked fresh daily.', 'https://github.com/fahsmaroc/images/raw/main/bread.jpg');
