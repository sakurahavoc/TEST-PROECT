# FAHS MAROC - Final Implementation Guide

## Overview

This document provides complete instructions for the Instagram Image Export feature and security implementation.

---

## ✅ What Was Implemented

### 1. Instagram Export Script (`admin/export_insta.php`)

A professional 1080x1080px image generator with the following features:

#### Visual Design ("NAQI" Style)

| Element | Description |
|---------|-------------|
| **Canvas** | 1080×1080 pixels (Instagram post size) |
| **Background** | Soft pastel gradient based on product category |
| **Logo** | FAHS logo at top-center (loaded from `assets/FAHS.png`) |
| **Tagline** | Arabic text: "دليلك للجودة والصحة" |
| **Instagram Handle** | @fahs.maroc displayed vertically on left edge |
| **Product Image** | Fetched from `image_url`, rendered with shadow |
| **Score Badge** | Colored circle (Green ≥70, Orange 40-69, Red <40) |
| **Nutrition Panel** | Right-side panel with all nutritional data |
| **Health Indicators** | Green/Red dots showing healthy/risky values |

#### Category Color Schemes

| Category ID | Category | Primary Color | Secondary Color |
|-------------|----------|---------------|-----------------|
| 1 | Dairy | Sky Blue | Powder Blue |
| 2 | Beverages | Turquoise | Light Sea Green |
| 3 | Snacks | Light Purple | Lavender |
| 4 | Breakfast | Light Yellow | Cream |
| 5 | Oils | Light Orange | Peach |
| 6 | Baby Food | Light Pink | Salmon |
| 7 | Bakery | Tan | Burlywood |
| 8 | Frozen | Light Cyan | Pale Blue |
| 9+ | Natural/Bio | Light Green | Mint |

---

### 2. Security Implementation

#### Authentication Layer
```php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth_check.php';
```
- Only logged-in admins can generate images
- CSRF protection via existing auth system

#### Input Validation
```php
$productId = isset($_GET['id']) ? filter_var($_GET['id'], FILTER_VALIDATE_INT) : 0;

if ($productId === false || $productId <= 0) {
    displayErrorImage('Invalid product ID...');
}
```
- Strict integer validation using `filter_var()`
- Rejects invalid or missing IDs gracefully

#### SQL Security
```php
$stmt = $db->prepare("
    SELECT p.*, c.name as category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.id = :id
    LIMIT 1
");
$stmt->execute([':id' => $productId]);
```
- PDO prepared statements with named parameters
- Prevents SQL injection attacks

#### Error Handling
```php
try {
    // Main generation logic
} catch (Exception $e) {
    error_log('Instagram Export Error: ' . $e->getMessage());
    displayErrorImage('An error occurred...');
}
```
- Graceful error display (shows error image instead of broken output)
- Errors logged to server (not exposed to users)

---

### 3. Admin .htaccess Security

Created `admin/.htaccess` with:

```apache
# Disable directory browsing
Options -Indexes

# Block access to sensitive files
<FilesMatch "\.(log|ini|conf|bak|sql|sh|zip)$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Security headers
Header set X-Content-Type-Options "nosniff"
Header set X-XSS-Protection "1; mode=block"
Header set X-Frame-Options "SAMEORIGIN"
```

---

## 📁 File Structure

```
fahs-maroc/
├── admin/
│   ├── export_insta.php      🆕 NEW - Instagram export script
│   ├── products.php          ✏️ Updated - Added export button
│   ├── .htaccess             🆕 NEW - Security configuration
│   └── ...
├── assets/
│   ├── FAHS.png              🆕 NEW - Logo file (placeholder)
│   ├── fonts/
│   │   ├── README.md         🆕 NEW - Font setup instructions
│   │   └── (upload TTF fonts here)
│   ├── FONTS_SETUP.md        🆕 NEW - Detailed font guide
│   └── LOGO_SETUP.md         🆕 NEW - Logo setup guide
├── index.php                 ✏️ Updated - Search + empty state
└── FINAL_IMPLEMENTATION_GUIDE.md  🆕 NEW - This file
```

---

## 🚀 Setup Instructions

### Step 1: Upload Fonts (Required for Best Quality)

#### Download Fonts:

1. **Inter Bold** (for English text):
   ```bash
   wget https://fonts.google.com/specimen/Inter
   # Or download manually from Google Fonts
   ```

2. **Cairo Bold** (for Arabic text):
   ```bash
   wget "https://fonts.google.com/download?family=Cairo"
   ```

#### Upload to Server:

```
/assets/fonts/
├── Inter-Bold.ttf     ← Upload this
├── Cairo-Bold.ttf     ← Upload this
└── README.md
```

**For Aeonfree:**
1. Login to cPanel → File Manager
2. Navigate to `public_html/assets/fonts/`
3. Click Upload → Select both TTF files

---

### Step 2: Upload Your Logo (Optional but Recommended)

1. Create or obtain your FAHS logo
2. Save as `FAHS.png` (PNG format with transparency)
3. Upload to `/assets/FAHS.png`

**If no logo is uploaded:** The script will draw a green circle with "F" as fallback.

---

### Step 3: Test the Export

1. Login to admin panel: `admin/login.php`
2. Go to "All Products": `admin/products.php`
3. Find any product with an image
4. Click the **pink camera icon** (🖼️) in the Actions column
5. The PNG should download automatically

**Direct URL test:**
```
https://your-domain.aeonfree.com/admin/export_insta.php?id=1
```

---

## 🎨 Usage Guide

### For Admins

#### Generating Instagram Images:

1. **Via Products List:**
   - Go to `admin/products.php`
   - Click the pink camera icon next to any product
   - Image downloads automatically

2. **Via Direct URL:**
   ```
   admin/export_insta.php?id=PRODUCT_ID
   ```

3. **Filename Format:**
   ```
   fahs_[product_name]_instagram.png
   ```
   Example: `fahs_fresh_milk_instagram.png`

#### Posting to Instagram:

1. Download the generated image
2. Open Instagram app
3. Create new post
4. Upload the image
5. Add caption with product details
6. Tag @fahs.maroc
7. Post!

---

## 🔧 Troubleshooting

### "Font not found" Error

**Problem:** Text appears pixelated or uses default font.

**Solution:**
```bash
# Check if fonts exist
ls -la assets/fonts/

# Should show:
# Inter-Bold.ttf
# Cairo-Bold.ttf
```

Upload fonts as described in Step 1.

---

### "Logo not found" Warning

**Problem:** Generic circle with "F" appears instead of logo.

**Solution:**
1. Create your logo (see `assets/LOGO_SETUP.md`)
2. Save as `FAHS.png`
3. Upload to `assets/FAHS.png`

---

### "Product image failed to load"

**Problem:** Product image shows "No Image" placeholder.

**Causes & Solutions:**

| Cause | Solution |
|-------|----------|
| Empty image_url | Add image URL in product edit |
| Invalid URL | Use direct image link (GitHub/MediaFire) |
| Remote server down | Try again later or re-upload image |
| Hotlink protection | Use different image host |

---

### "Access denied" Error

**Problem:** Can't access export_insta.php.

**Solution:**
1. Ensure you're logged in as admin
2. Check `includes/auth_check.php` exists
3. Verify session is active

---

### "Broken image" or White Screen

**Problem:** Browser shows broken image icon.

**Solution:**
1. Check PHP error logs
2. Verify GD Library is installed:
   ```php
   <?php phpinfo(); // Look for GD section ?>
   ```
3. Increase memory limit in `.htaccess`:
   ```apache
   php_value memory_limit 256M
   ```

---

## 📊 Technical Specifications

### Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| PHP | 8.0 | 8.1+ |
| GD Library | 2.0+ | Latest |
| FreeType | Enabled | Enabled |
| Memory | 128MB | 256MB |

### Image Specifications

| Property | Value |
|----------|-------|
| Dimensions | 1080 × 1080 pixels |
| Format | PNG |
| Color Depth | 24-bit + Alpha |
| File Size | ~500KB - 2MB |
| DPI | 72 |

---

## 🔒 Security Checklist

- [x] Authentication required (auth_check.php)
- [x] Input validation (filter_var)
- [x] PDO prepared statements
- [x] Error handling (try-catch)
- [x] .htaccess protection
- [x] Directory browsing disabled
- [x] Sensitive files blocked
- [x] Security headers enabled

---

## 📈 Performance Optimization

### For Better Performance:

1. **Cache Generated Images:**
   ```php
   // Add caching headers
   header('Cache-Control: public, max-age=86400');
   ```

2. **Optimize Product Images:**
   - Compress before uploading
   - Use appropriate dimensions (max 800px)
   - Use WebP format when possible

3. **Use CDN for Fonts:**
   - Host fonts on CDN
   - Faster loading for users

---

## 📝 Code Examples

### Customizing Colors

Edit `getCategoryColors()` function:

```php
function getCategoryColors(int $categoryId): array {
    $schemes = [
        1 => [
            'primary'   => [135, 206, 235],  // Change these RGB values
            'secondary' => [176, 224, 230],
            'accent'    => [70, 130, 180],
        ],
        // ...
    ];
    return $schemes[$categoryId] ?? $schemes[9];
}
```

### Adding New Nutrients

Edit the `$nutrients` array:

```php
$nutrients = [
    ['key' => 'protein', 'label' => 'Protein', 'unit' => 'g'],
    ['key' => 'fiber',   'label' => 'Fiber',   'unit' => 'g'], // Add this
    // ...
];
```

### Changing Font Sizes

Edit the constants at the top:

```php
define('FONT_SIZE_SCORE', 72);      // Was 64
define('FONT_SIZE_TITLE', 42);       // Was 36
```

---

## 🆘 Support

### Getting Help

| Issue | Contact |
|-------|---------|
| Technical problems | contact@fahsmaroc.ma |
| Feature requests | Instagram @fahs.maroc |
| Bug reports | GitHub Issues |

### Debug Mode

Enable debug output temporarily:

```php
// At top of export_insta.php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

**Remember to disable in production!**

---

## 📜 License & Credits

### Fonts
- **Inter**: SIL Open Font License 1.1
- **Cairo**: SIL Open Font License 1.1

### Code
- FAHS MAROC Team
- Built with PHP GD Library

---

## 🎯 Future Enhancements

Planned features for future versions:

- [ ] Batch export multiple products
- [ ] Instagram Stories format (1080×1920)
- [ ] Custom templates/themes
- [ ] QR code integration
- [ ] Auto-post to Instagram API
- [ ] Image caching system

---

**Last Updated:** April 2026  
**Version:** 2.0.0  
**Author:** FAHS MAROC Team
