<?php
/**
 * FAHS MAROC - Header Template
 */
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="FAHS MAROC - Your digital guide for food quality and health in Morocco">
    <meta name="keywords" content="food quality, health, Morocco, nutrition, product directory">
    <meta name="author" content="FAHS MAROC">
    
    <title><?php echo isset($pageTitle) ? sanitize($pageTitle) . ' | ' : ''; ?><?php echo APP_NAME; ?></title>
    
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Tailwind Configuration -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        fahs: {
                            green: '#2D5A27',
                            'green-light': '#4A7C43',
                            'green-dark': '#1E3D1A',
                            white: '#FFFFFF',
                            gray: '#F5F5F5',
                            'gray-dark': '#333333'
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'system-ui', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom Styles -->
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        .gradient-hero {
            background: linear-gradient(135deg, #2D5A27 0%, #4A7C43 100%);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 40px rgba(45, 90, 39, 0.15);
        }
    </style>
    
    <!-- CSRF Token for AJAX requests -->
    <meta name="csrf-token" content="<?php echo generateCSRFToken(); ?>">
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">
    
    <!-- Navigation -->
    <nav class="bg-fahs-green shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Logo -->
                <div class="flex items-center">
                    <a href="<?php echo APP_URL; ?>/index.php" class="flex items-center space-x-2">
                        <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                            <span class="text-fahs-green font-bold text-xl">F</span>
                        </div>
                        <span class="text-white font-bold text-xl tracking-wide">FAHS MAROC</span>
                    </a>
                </div>
                
                <!-- Desktop Navigation -->
                <div class="hidden md:flex items-center space-x-8">
                    <a href="<?php echo APP_URL; ?>/index.php" class="text-white hover:text-green-200 transition-colors font-medium">Home</a>
                    <a href="<?php echo APP_URL; ?>/products.php" class="text-white hover:text-green-200 transition-colors font-medium">Products</a>
                    <a href="<?php echo APP_URL; ?>/categories.php" class="text-white hover:text-green-200 transition-colors font-medium">Categories</a>
                    <a href="<?php echo APP_URL; ?>/about.php" class="text-white hover:text-green-200 transition-colors font-medium">About</a>
                    
                    <?php if (isLoggedIn()): ?>
                        <a href="<?php echo APP_URL; ?>/admin/dashboard.php" class="bg-white text-fahs-green px-4 py-2 rounded-lg font-medium hover:bg-green-100 transition-colors">
                            Dashboard
                        </a>
                        <a href="<?php echo APP_URL; ?>/admin/logout.php" class="text-white hover:text-green-200 transition-colors">
                            Logout
                        </a>
                    <?php else: ?>
                        <a href="<?php echo APP_URL; ?>/admin/login.php" class="bg-white text-fahs-green px-4 py-2 rounded-lg font-medium hover:bg-green-100 transition-colors">
                            Admin Login
                        </a>
                    <?php endif; ?>
                </div>
                
                <!-- Mobile Menu Button -->
                <div class="md:hidden flex items-center">
                    <button id="mobile-menu-btn" class="text-white hover:text-green-200 focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-fahs-green-dark">
            <div class="px-4 pt-2 pb-4 space-y-1">
                <a href="<?php echo APP_URL; ?>/index.php" class="block text-white hover:bg-fahs-green-light px-3 py-2 rounded-md">Home</a>
                <a href="<?php echo APP_URL; ?>/products.php" class="block text-white hover:bg-fahs-green-light px-3 py-2 rounded-md">Products</a>
                <a href="<?php echo APP_URL; ?>/categories.php" class="block text-white hover:bg-fahs-green-light px-3 py-2 rounded-md">Categories</a>
                <a href="<?php echo APP_URL; ?>/about.php" class="block text-white hover:bg-fahs-green-light px-3 py-2 rounded-md">About</a>
                <?php if (isLoggedIn()): ?>
                    <a href="<?php echo APP_URL; ?>/admin/dashboard.php" class="block text-white hover:bg-fahs-green-light px-3 py-2 rounded-md">Dashboard</a>
                    <a href="<?php echo APP_URL; ?>/admin/logout.php" class="block text-white hover:bg-fahs-green-light px-3 py-2 rounded-md">Logout</a>
                <?php else: ?>
                    <a href="<?php echo APP_URL; ?>/admin/login.php" class="block text-white hover:bg-fahs-green-light px-3 py-2 rounded-md">Admin Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <!-- Flash Messages -->
    <?php $flash = getFlashMessage(); if ($flash): ?>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
            <div class="rounded-lg p-4 <?php 
                echo match($flash['type']) {
                    'success' => 'bg-green-100 text-green-800 border border-green-200',
                    'error' => 'bg-red-100 text-red-800 border border-red-200',
                    'warning' => 'bg-yellow-100 text-yellow-800 border border-yellow-200',
                    default => 'bg-blue-100 text-blue-800 border border-blue-200'
                };
            ?>">
                <div class="flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <?php if ($flash['type'] === 'success'): ?>
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                        <?php elseif ($flash['type'] === 'error'): ?>
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                        <?php else: ?>
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                        <?php endif; ?>
                    </svg>
                    <?php echo sanitize($flash['message']); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Main Content Wrapper -->
    <main class="flex-grow">
