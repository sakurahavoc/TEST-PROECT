<?php
/**
 * FAHS MAROC - Configuration File
 * Database Connection using PDO
 * 
 * @package FAHS_MAROC
 * @author FAHS Team
 * @version 1.0.0
 */

// =====================================================
// Environment Configuration
// =====================================================

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Session configuration
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// =====================================================
// Database Configuration
// Adjust these values for your Aeonfree hosting
// =====================================================

define('DB_HOST', 'localhost');      // MySQL host (usually localhost on Aeonfree)
define('DB_NAME', 'fahs_maroc');     // Database name
define('DB_USER', 'your_db_user');   // Your database username
define('DB_PASS', 'your_db_pass');   // Your database password
define('DB_CHARSET', 'utf8mb4');     // Character set

// =====================================================
// Application Configuration
// =====================================================

define('APP_NAME', 'FAHS MAROC');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'https://your-domain.aeonfree.com'); // Update with your actual URL
define('APP_EMAIL', 'contact@fahsmaroc.ma');

// Security settings
define('HASH_COST', 12); // Bcrypt cost factor for password hashing

// =====================================================
// PDO Database Connection
// =====================================================

/**
 * Get PDO Database Connection
 * 
 * @return PDO
 * @throws PDOException
 */
function getDBConnection(): PDO {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Throw exceptions on errors
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Fetch associative arrays
                PDO::ATTR_EMULATE_PREPARES   => false,                  // Use real prepared statements
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET . " COLLATE utf8mb4_unicode_ci"
            ];
            
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            
        } catch (PDOException $e) {
            // Log error (don't expose details in production)
            error_log("Database Connection Error: " . $e->getMessage());
            throw new Exception("Database connection failed. Please try again later.");
        }
    }
    
    return $pdo;
}

// =====================================================
// Helper Functions
// =====================================================

/**
 * Sanitize user input
 * 
 * @param string $data
 * @return string
 */
function sanitize(string $data): string {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate CSRF Token
 * 
 * @return string
 */
function generateCSRFToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF Token
 * 
 * @param string $token
 * @return bool
 */
function verifyCSRFToken(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Hash password securely
 * 
 * @param string $password
 * @return string
 */
function hashPassword(string $password): string {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
}

/**
 * Verify password
 * 
 * @param string $password
 * @param string $hash
 * @return bool
 */
function verifyPassword(string $password, string $hash): bool {
    return password_verify($password, $hash);
}

/**
 * Redirect to URL
 * 
 * @param string $url
 * @return void
 */
function redirect(string $url): void {
    header("Location: " . $url);
    exit();
}

/**
 * Set flash message
 * 
 * @param string $type (success, error, warning, info)
 * @param string $message
 * @return void
 */
function setFlashMessage(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Get and clear flash message
 * 
 * @return array|null
 */
function getFlashMessage(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Check if user is logged in
 * 
 * @return bool
 */
function isLoggedIn(): bool {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

/**
 * Require authentication
 * 
 * @return void
 */
function requireAuth(): void {
    if (!isLoggedIn()) {
        setFlashMessage('error', 'Please login to access this page.');
        redirect(APP_URL . '/admin/login.php');
    }
}

/**
 * Format health score with color class
 * 
 * @param int $score
 * @return string
 */
function getScoreColorClass(int $score): string {
    if ($score >= 80) return 'text-green-600 bg-green-100';
    if ($score >= 60) return 'text-yellow-600 bg-yellow-100';
    if ($score >= 40) return 'text-orange-600 bg-orange-100';
    return 'text-red-600 bg-red-100';
}

/**
 * Format number with unit
 * 
 * @param float|null $value
 * @param string $unit
 * @return string
 */
function formatNutrient(?float $value, string $unit): string {
    return $value !== null ? number_format($value, 2) . ' ' . $unit : 'N/A';
}

?>
