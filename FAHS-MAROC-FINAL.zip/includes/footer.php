<?php
/**
 * FAHS MAROC - Footer Template
 */
?>
    </main><!-- End Main Content -->
    
    <!-- Footer -->
    <footer class="bg-fahs-green-dark text-white mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                
                <!-- Brand -->
                <div class="col-span-1 md:col-span-1">
                    <div class="flex items-center space-x-2 mb-4">
                        <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                            <span class="text-fahs-green font-bold text-xl">F</span>
                        </div>
                        <span class="font-bold text-xl">FAHS MAROC</span>
                    </div>
                    <p class="text-green-200 text-sm leading-relaxed">
                        Your trusted digital guide for food quality and health in Morocco. Making informed choices for a healthier life.
                    </p>
                </div>
                
                <!-- Quick Links -->
                <div>
                    <h3 class="font-semibold text-lg mb-4">Quick Links</h3>
                    <ul class="space-y-2 text-green-200">
                        <li><a href="<?php echo APP_URL; ?>/index.php" class="hover:text-white transition-colors">Home</a></li>
                        <li><a href="<?php echo APP_URL; ?>/products.php" class="hover:text-white transition-colors">Products</a></li>
                        <li><a href="<?php echo APP_URL; ?>/categories.php" class="hover:text-white transition-colors">Categories</a></li>
                        <li><a href="<?php echo APP_URL; ?>/about.php" class="hover:text-white transition-colors">About Us</a></li>
                    </ul>
                </div>
                
                <!-- Categories -->
                <div>
                    <h3 class="font-semibold text-lg mb-4">Categories</h3>
                    <ul class="space-y-2 text-green-200">
                        <li><a href="#" class="hover:text-white transition-colors">Dairy Products</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Beverages</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Snacks</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Baby Food</a></li>
                    </ul>
                </div>
                
                <!-- Contact -->
                <div>
                    <h3 class="font-semibold text-lg mb-4">Contact</h3>
                    <ul class="space-y-2 text-green-200">
                        <li class="flex items-center space-x-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            <span><?php echo APP_EMAIL; ?></span>
                        </li>
                        <li class="flex items-center space-x-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                            </svg>
                            <span>Morocco</span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Bottom Bar -->
            <div class="border-t border-green-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
                <p class="text-green-200 text-sm">
                    &copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.
                </p>
                <p class="text-green-300 text-sm mt-2 md:mt-0">
                    Version <?php echo APP_VERSION; ?>
                </p>
            </div>
        </div>
    </footer>
    
    <!-- Mobile Menu Toggle Script -->
    <script>
        document.getElementById('mobile-menu-btn')?.addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
    
</body>
</html>
