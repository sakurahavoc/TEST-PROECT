<?php
/**
 * FAHS MAROC - Authentication Check
 * 
 * Include this file at the top of any protected admin page.
 * It will redirect unauthenticated users to the login page.
 * 
 * Usage: require_once __DIR__ . '/../includes/auth_check.php';
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || empty($_SESSION['admin_id'])) {
    // Store the requested URL for redirect after login (optional)
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    
    // Set flash message
    if (!isset($_SESSION['flash'])) {
        $_SESSION['flash'] = [
            'type' => 'warning',
            'message' => 'Please login to access this page.'
        ];
    }
    
    // Redirect to login page
    header('Location: ' . (defined('APP_URL') ? APP_URL : '') . '/admin/login.php');
    exit();
}

// Optional: Check if session has expired (e.g., after 2 hours of inactivity)
$session_timeout = 7200; // 2 hours in seconds
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    // Session expired, destroy it
    $_SESSION = [];
    
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    session_destroy();
    
    // Start new session for flash message
    session_start();
    $_SESSION['flash'] = [
        'type' => 'warning',
        'message' => 'Your session has expired. Please login again.'
    ];
    
    header('Location: ' . (defined('APP_URL') ? APP_URL : '') . '/admin/login.php');
    exit();
}

// Update last activity time
$_SESSION['last_activity'] = time();

// Optional: Regenerate session ID periodically for security
if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} else if (time() - $_SESSION['created'] > 1800) {
    // Regenerate session ID every 30 minutes
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}
?>
