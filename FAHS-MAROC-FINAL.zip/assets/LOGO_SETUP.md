# FAHS MAROC - Logo Setup Guide

## Overview

The Instagram Export feature (`admin/export_insta.php`) requires a logo file to display at the top of generated images.

---

## Required Logo File

### File Location
```
/assets/FAHS.png
```

### Specifications

| Property | Recommended Value |
|----------|-------------------|
| **Format** | PNG (with transparency) |
| **Size** | 200x200 pixels or larger |
| **Shape** | Square or circular |
| **Background** | Transparent |
| **Colors** | Match your brand colors |

---

## Creating Your Logo

### Option 1: Design Your Own

Use tools like:
- **Canva** (https://www.canva.com) - Free, easy to use
- **Adobe Illustrator** - Professional vector design
- **Figma** (https://figma.com) - Free design tool
- **Photoshop** - Professional image editing

### Option 2: Hire a Designer

Platforms:
- **Fiverr** - Budget-friendly designers
- **99designs** - Professional logo contests
- **Upwork** - Freelance designers

### Option 3: Use a Logo Generator

Free tools:
- **Looka** (https://looka.com)
- **Hatchful** (https://hatchful.shopify.com)
- **LogoMakr** (https://logomakr.com)

---

## Logo Design Tips

### For FAHS MAROC Brand

1. **Color Scheme:**
   - Primary: `#2D5A27` (FAHS Green)
   - Secondary: `#4A7C43` (Light Green)
   - Accent: White or Gold

2. **Elements to Include:**
   - Letter "F" or "ف" (Arabic F)
   - Food/health related icon (leaf, heart, etc.)
   - Moroccan cultural elements (optional)

3. **Style:**
   - Modern and clean
   - Professional but approachable
   - Works well at small sizes

### Example Logo Concept

```
    🌿
   ╱  ╲
  ╱ F  ╲
 ╱______╲
  FAHS
```

---

## Uploading Your Logo

### For Aeonfree (cPanel)

1. Login to your Aeonfree cPanel
2. Open **File Manager**
3. Navigate to: `public_html/assets/`
4. Click **Upload**
5. Select your `FAHS.png` file
6. Verify the file is named exactly `FAHS.png`

### Using FTP

```bash
# Connect via FTP
ftp your-domain.aeonfree.com

# Navigate to assets folder
cd public_html/assets/

# Upload logo
put FAHS.png

# Verify
ls -la
```

### Using FileZilla

1. Connect to your server
2. Navigate to `/public_html/assets/`
3. Drag `FAHS.png` from your computer
4. Wait for upload to complete

---

## Testing Your Logo

After uploading, verify it works:

```php
<?php
// test_logo.php - Place in root directory
$logoPath = 'assets/FAHS.png';

if (file_exists($logoPath)) {
    $info = getimagesize($logoPath);
    echo "<h2>✅ Logo Found!</h2>";
    echo "<p>Path: $logoPath</p>";
    echo "<p>Size: " . $info[0] . "x" . $info[1] . " pixels</p>";
    echo "<p>Type: " . $info['mime'] . "</p>";
    echo "<img src='$logoPath' width='200'>";
} else {
    echo "<h2>❌ Logo Not Found</h2>";
    echo "<p>Expected at: $logoPath</p>";
    echo "<p>Please upload your logo file.</p>";
}
```

---

## Fallback Behavior

If no logo is found, the export script will:
1. Draw a white circle
2. Place the letter "F" inside
3. Use your brand colors

This ensures the image still looks professional even without a custom logo.

---

## Logo Variants (Optional)

You may want multiple logo versions:

```
/assets/
├── FAHS.png           # Main logo (required)
├── FAHS-white.png     # White version for dark backgrounds
├── FAHS-icon.png      # Icon-only version (for favicon)
└── FAHS-full.png      # Full logo with tagline
```

---

## Troubleshooting

### Logo Not Displaying

**Check:**
1. File is named exactly `FAHS.png` (case-sensitive)
2. File is in `/assets/` directory
3. File permissions are readable (644)
4. Image format is PNG or JPEG

### Logo Looks Blurry

**Solution:**
1. Use higher resolution image (400x400 or larger)
2. Ensure original image is sharp
3. Use PNG format for better quality

### Wrong Colors

**Solution:**
1. Use PNG with transparency
2. Avoid JPEG compression artifacts
3. Use consistent brand colors

---

## Free Logo Resources

### Icons (for logo elements)
- **Flaticon** (https://flaticon.com)
- **Icons8** (https://icons8.com)
- **Iconfinder** (https://iconfinder.com)

### Inspiration
- **Dribbble** (https://dribbble.com)
- **Behance** (https://behance.net)
- **Pinterest** (search "food logo design")

---

## Example: Simple Text Logo

If you don't have a logo yet, create a simple one:

```php
<?php
// create_simple_logo.php - Run once to generate logo

$size = 200;
$image = imagecreatetruecolor($size, $size);

// Transparent background
imagealphablending($image, false);
imagesavealpha($image, true);
$transparent = imagecolorallocatealpha($image, 0, 0, 0, 127);
imagefill($image, 0, 0, $transparent);

// FAHS Green circle
$green = imagecolorallocate($image, 45, 90, 39);
imagefilledellipse($image, $size/2, $size/2, $size-20, $size-20, $green);

// White "F"
$white = imagecolorallocate($image, 255, 255, 255);
imagestring($image, 5, $size/2 - 10, $size/2 - 10, 'F', $white);

// Save
imagepng($image, 'assets/FAHS.png');
imagedestroy($image);

echo "Simple logo created at assets/FAHS.png\n";
```

---

## Support

Need help with your logo?
- Instagram: @fahs.maroc
- Email: contact@fahsmaroc.ma

---

**Last Updated:** April 2026  
**Version:** 1.0.0
