# FAHS MAROC - Fonts Directory

This directory contains TrueType Font (TTF) files used by the Instagram Export feature (`admin/export_insta.php`).

## Purpose

The Instagram Export feature uses PHP GD Library to generate professional 1080x1080px PNG images for social media posts. TTF fonts provide better text rendering quality compared to built-in GD fonts.

## Font Setup for Aeonfree Hosting

### Option 1: Upload a TTF Font (Recommended)

1. Download a free font like **DejaVu Sans** or **Arial**:
   - DejaVu Fonts: https://dejavu-fonts.github.io/
   - Google Fonts: https://fonts.google.com/

2. Upload the `.ttf` file to this directory (`/assets/fonts/`)

3. The export script will automatically detect and use the font

### Option 2: Use System Fonts (Fallback)

If no TTF font is uploaded, the script will automatically fall back to PHP's built-in fonts. The image will still be generated, but text quality may be lower.

### Option 3: Link to External Font (Advanced)

You can modify `admin/export_insta.php` to load fonts from an external URL:

```php
// Add this at the beginning of the script
$fontUrl = 'https://your-cdn.com/fonts/arial.ttf';
$fontPath = __DIR__ . '/../assets/fonts/downloaded.ttf';

if (!file_exists($fontPath)) {
    file_put_contents($fontPath, file_get_contents($fontUrl));
}
```

## Recommended Fonts

| Font Name | Style | License | Best For |
|-----------|-------|---------|----------|
| DejaVu Sans | Sans-serif | Free | General text, Arabic support |
| Arial | Sans-serif | Proprietary | Clean, professional look |
| Open Sans | Sans-serif | OFL | Modern, web-friendly |
| Roboto | Sans-serif | Apache | Google's standard font |

## Arabic Text Support

For proper Arabic text rendering (e.g., "دليلك للجودة والصحة"), use a font with Arabic glyph support:

- **DejaVu Sans** - Good Arabic support
- **Arial** - Full Arabic support (Windows/Mac)
- **Noto Sans Arabic** - Google's Arabic font (https://fonts.google.com/noto/specimen/Noto+Sans+Arabic)

## Troubleshooting

### "Font not found" Error
- Ensure the `.ttf` file is uploaded to `/assets/fonts/`
- Check file permissions (should be readable: 644)

### Arabic Text Not Displaying
- Use a font with Arabic Unicode support
- Verify the font file includes Arabic glyphs

### Text Looks Blurry
- Use a higher quality TTF font file
- Ensure the font size in the script matches your needs

## File Structure

```
assets/fonts/
├── README.md          # This file
├── arial.ttf          # Example: Arial font (optional)
├── DejaVuSans.ttf     # Example: DejaVu Sans (optional)
└── ...                # Add your TTF files here
```

## Default Font Search Paths

The export script searches for fonts in this order:

1. `/assets/fonts/arial.ttf`
2. `/assets/fonts/DejaVuSans.ttf`
3. System paths:
   - `/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf`
   - `/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf`
   - `/usr/share/fonts/truetype/freefont/FreeSans.ttf`

If no TTF font is found, built-in GD fonts are used as fallback.
