# FAHS MAROC - Font Setup Guide

## Overview

This guide explains how to set up custom fonts for the Instagram Export feature (`admin/export_insta.php`). Proper fonts are essential for professional-looking Instagram graphics.

---

## Why Fonts Matter

The Instagram export feature uses PHP's GD Library to generate images. Without custom TrueType fonts (TTF), the text will use GD's built-in bitmap fonts which:
- Look pixelated and unprofessional
- Don't support Arabic text properly
- Have limited styling options

With custom TTF fonts, you get:
- Smooth, scalable vector text
- Full Arabic language support
- Professional typography
- Better brand consistency

---

## Required Fonts

### 1. Primary Font: Inter (for English/Latin text)

**Download:** https://fonts.google.com/specimen/Inter

**Files needed:**
- `Inter-Bold.ttf` - For headings and bold text
- `Inter-Regular.ttf` - For body text (optional)

**Installation:**
```bash
# Download from Google Fonts
wget https://github.com/rsms/inter/releases/download/v4.0/Inter-4.0.zip
unzip Inter-4.0.zip

# Copy to fonts directory
cp Inter-4.0/Inter-Bold.ttf /assets/fonts/
```

---

### 2. Arabic Font: Cairo (for Arabic text)

**Download:** https://fonts.google.com/specimen/Cairo

**Files needed:**
- `Cairo-Bold.ttf` - For Arabic headings
- `Cairo-Regular.ttf` - For Arabic body text (optional)

**Installation:**
```bash
# Download from Google Fonts
wget "https://fonts.google.com/download?family=Cairo" -O cairo.zip
unzip cairo.zip

# Copy to fonts directory
cp Cairo-Bold.ttf /assets/fonts/
```

---

### 3. Alternative: Noto Sans Arabic

**Download:** https://fonts.google.com/noto/specimen/Noto+Sans+Arabic

**Best for:** Comprehensive Arabic script support including all variants

---

## Quick Setup Instructions

### Method 1: Manual Download (Easiest)

1. **Download Inter Bold:**
   - Go to https://fonts.google.com/specimen/Inter
   - Click "Get font" → "Download"
   - Extract the ZIP file
   - Find `Inter-Bold.ttf`

2. **Download Cairo Bold:**
   - Go to https://fonts.google.com/specimen/Cairo
   - Click "Get font" → "Download"
   - Extract the ZIP file
   - Find `Cairo-Bold.ttf`

3. **Upload to your server:**
   ```
   /assets/fonts/
   ├── Inter-Bold.ttf
   └── Cairo-Bold.ttf
   ```

### Method 2: Using wget/cURL (For VPS/Dedicated Servers)

```bash
# Navigate to fonts directory
cd /path/to/your/website/assets/fonts/

# Download Inter font
wget https://github.com/rsms/inter/releases/download/v4.0/Inter-4.0.zip
unzip Inter-4.0.zip
mv Inter-4.0/Inter-Bold.ttf ./
rm -rf Inter-4.0 Inter-4.0.zip

# Download Cairo font
wget "https://fonts.google.com/download?family=Cairo" -O cairo.zip
unzip cairo.zip
mv Cairo-Bold.ttf ./
rm -f cairo.zip *.ttf  # Keep only Cairo-Bold.ttf

# Set permissions
chmod 644 *.ttf
```

### Method 3: For Aeonfree (cPanel/File Manager)

1. Download fonts to your computer:
   - [Inter-Bold.ttf](https://fonts.google.com/specimen/Inter)
   - [Cairo-Bold.ttf](https://fonts.google.com/specimen/Cairo)

2. Login to Aeonfree cPanel

3. Open File Manager

4. Navigate to: `public_html/assets/fonts/`

5. Click "Upload" and select both TTF files

6. Verify files are uploaded successfully

---

## Expected File Structure

```
fahs-maroc/
├── assets/
│   ├── FAHS.png              # Your logo (see below)
│   ├── fonts/
│   │   ├── Inter-Bold.ttf    # English text font
│   │   ├── Cairo-Bold.ttf    # Arabic text font
│   │   └── README.md         # This file
│   └── FONTS_SETUP.md        # This guide
└── ...
```

---

## Font Configuration in Code

The export script (`admin/export_insta.php`) automatically looks for fonts in this order:

```php
$fontPaths = [
    FONTS_DIR . 'Inter-Bold.ttf',
    FONTS_DIR . 'Cairo-Bold.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
];
```

If no TTF font is found, it falls back to GD's built-in fonts.

---

## Testing Font Installation

After uploading fonts, test with this simple PHP script:

```php
<?php
// test_fonts.php - Place in root directory
$fonts = [
    'assets/fonts/Inter-Bold.ttf',
    'assets/fonts/Cairo-Bold.ttf',
];

echo "<h2>Font Test Results</h2>";

foreach ($fonts as $font) {
    $exists = file_exists($font);
    $readable = $exists ? is_readable($font) : false;
    
    echo "<p>";
    echo "<strong>$font:</strong> ";
    echo $exists ? "✅ File exists" : "❌ File NOT found";
    echo " | ";
    echo $readable ? "✅ Readable" : "❌ Not readable";
    echo "</p>";
}

echo "<p><strong>GD Library:</strong> " . (extension_loaded('gd') ? "✅ Installed" : "❌ Not installed") . "</p>";
echo "<p><strong>FreeType Support:</strong> " . (function_exists('imagettftext') ? "✅ Available" : "❌ Not available") . "</p>";
```

---

## Troubleshooting

### "Font not found" Error

**Problem:** The script can't find the font files.

**Solution:**
1. Check file path is correct: `assets/fonts/Inter-Bold.ttf`
2. Verify file permissions: Should be `644` (readable)
3. Check file was uploaded completely (not corrupted)

### Arabic Text Not Displaying

**Problem:** Arabic characters show as squares or question marks.

**Solution:**
1. Ensure Cairo or Noto Sans Arabic font is uploaded
2. Verify the font file includes Arabic glyphs
3. Check PHP has UTF-8 support enabled

### Text Looks Blurry

**Problem:** Generated text appears pixelated.

**Solution:**
1. Use a high-quality TTF font file
2. Ensure font size is appropriate (not too small)
3. Check GD Library is properly installed

### "imagettftext() function not found"

**Problem:** PHP doesn't have FreeType support.

**Solution:**
- Contact your hosting provider to enable FreeType support
- Or use a different hosting provider with full GD support

---

## Font Licenses

### Inter Font
- **License:** SIL Open Font License 1.1
- **Commercial use:** ✅ Allowed
- **Modification:** ✅ Allowed
- **Attribution:** Not required

### Cairo Font
- **License:** SIL Open Font License 1.1
- **Commercial use:** ✅ Allowed
- **Modification:** ✅ Allowed
- **Attribution:** Not required

Both fonts are free for commercial use without attribution.

---

## Alternative Fonts

If you prefer different fonts, these are also excellent choices:

| Font | Best For | Download |
|------|----------|----------|
| **Roboto** | Modern, clean look | https://fonts.google.com/specimen/Roboto |
| **Open Sans** | Highly readable | https://fonts.google.com/specimen/Open+Sans |
| **Montserrat** | Bold headlines | https://fonts.google.com/specimen/Montserrat |
| **Noto Sans** | Universal language support | https://fonts.google.com/noto |
| **Tajawal** | Arabic (alternative to Cairo) | https://fonts.google.com/specimen/Tajawal |

---

## Performance Tips

1. **Only upload needed weights** - Don't upload all font variants, just Bold
2. **Compress fonts** - Use woff2 for web (though TTF needed for GD)
3. **Cache generated images** - Consider caching to reduce server load
4. **Optimize images** - Compress product images before uploading

---

## Support

For font-related issues:
- Instagram: @fahs.maroc
- Email: contact@fahsmaroc.ma

---

**Last Updated:** April 2026  
**Version:** 1.0.0
