<?php
/**
 * FAHS MAROC - Product Details Page
 * Single product view with full nutritional information
 */
require_once __DIR__ . '/includes/config.php';

$db = getDBConnection();

// Get product ID
$productId = (int)($_GET['id'] ?? 0);

if ($productId <= 0) {
    header('Location: index.php');
    exit;
}

// Fetch product
$stmt = $db->prepare("SELECT p.*, c.name as category_name 
                      FROM products p 
                      LEFT JOIN categories c ON p.category_id = c.id 
                      WHERE p.id = ?");
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: index.php');
    exit;
}

// Fetch related products (same category, excluding current)
$relatedStmt = $db->prepare("SELECT p.*, c.name as category_name 
                             FROM products p 
                             LEFT JOIN categories c ON p.category_id = c.id 
                             WHERE p.category_id = ? AND p.id != ? 
                             ORDER BY p.score DESC 
                             LIMIT 4");
$relatedStmt->execute([$product['category_id'], $productId]);
$relatedProducts = $relatedStmt->fetchAll();

// Helper function for score badge
function getScoreBadgeClass($score) {
    if ($score === null) return 'bg-gray-100 text-gray-600';
    if ($score >= 70) return 'bg-green-500 text-white';
    if ($score >= 40) return 'bg-orange-500 text-white';
    return 'bg-red-500 text-white';
}

function getScoreLabel($score) {
    if ($score === null) return 'Not Rated';
    if ($score >= 70) return 'Excellent';
    if ($score >= 40) return 'Average';
    return 'Poor';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo htmlspecialchars($product['name']); ?> - <?php echo htmlspecialchars($product['brand'] ?? 'Product details'); ?> on FAHS MAROC">
    <title><?php echo htmlspecialchars($product['name']); ?> | FAHS MAROC</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        fahs: {
                            green: '#2D5A27',
                            'green-light': '#4A7C43',
                            'green-dark': '#1E3D1A',
                        }
                    }
                }
            }
        }
    </script>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        body { font-family: 'Inter', sans-serif; }
        .gradient-hero {
            background: linear-gradient(135deg, #2D5A27 0%, #4A7C43 100%);
        }
        .nutrition-bar {
            height: 8px;
            border-radius: 4px;
            background: #e5e7eb;
            overflow: hidden;
        }
        .nutrition-bar-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.5s ease;
        }
    </style>
</head>
<body class="bg-gray-50">
    
    <!-- Navigation Header -->
    <header class="bg-white shadow-sm sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <!-- Logo -->
                <a href="index.php" class="flex items-center space-x-3">
                    <img src="assets/images/logo.png" 
                         alt="FAHS MAROC Logo" 
                         class="h-10 w-10 object-contain"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="hidden w-10 h-10 bg-fahs-green rounded-full items-center justify-center">
                        <span class="text-white font-bold text-lg">F</span>
                    </div>
                    <span class="text-xl font-bold text-gray-800">FAHS MAROC</span>
                </a>
                
                <!-- Navigation -->
                <nav class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-600 hover:text-fahs-green transition-colors">Home</a>
                    <a href="about.php" class="text-gray-600 hover:text-fahs-green transition-colors">About</a>
                    <a href="admin/login.php" class="text-gray-600 hover:text-fahs-green transition-colors">Admin</a>
                </nav>
                
                <!-- Search -->
                <form method="GET" action="index.php" class="flex items-center">
                    <div class="relative">
                        <input type="text" 
                               name="search" 
                               placeholder="Search..."
                               class="w-48 lg:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-full text-sm focus:ring-2 focus:ring-fahs-green focus:border-transparent">
                        <svg class="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                </form>
                
                <!-- Mobile Menu Button -->
                <button id="mobile-menu-btn" class="md:hidden p-2 rounded-lg hover:bg-gray-100">
                    <svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t">
            <div class="px-4 py-3 space-y-2">
                <a href="index.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">Home</a>
                <a href="about.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">About</a>
                <a href="admin/login.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">Admin</a>
            </div>
        </div>
    </header>
    
    <!-- Breadcrumb -->
    <div class="bg-white border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
            <nav class="flex items-center text-sm text-gray-500">
                <a href="index.php" class="hover:text-fahs-green transition-colors">Home</a>
                <svg class="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                </svg>
                <?php if ($product['category_name']): ?>
                    <a href="index.php?cat=<?php echo $product['category_id']; ?>" class="hover:text-fahs-green transition-colors">
                        <?php echo htmlspecialchars($product['category_name']); ?>
                    </a>
                    <svg class="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                    </svg>
                <?php endif; ?>
                <span class="text-gray-800 font-medium truncate max-w-xs"><?php echo htmlspecialchars($product['name']); ?></span>
            </nav>
        </div>
    </div>
    
    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Product Header -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden mb-8">
            <div class="grid grid-cols-1 lg:grid-cols-2">
                <!-- Product Image -->
                <div class="bg-gray-100 relative h-80 lg:h-auto">
                    <?php if ($product['image_url']): ?>
                        <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($product['name']); ?>"
                             class="w-full h-full object-cover"
                             onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                        <div class="hidden w-full h-full items-center justify-center">
                            <svg class="w-32 h-32 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                            </svg>
                        </div>
                    <?php else: ?>
                        <div class="w-full h-full flex items-center justify-center">
                            <svg class="w-32 h-32 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                            </svg>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Product Info -->
                <div class="p-8">
                    <!-- Category Badge -->
                    <?php if ($product['category_name']): ?>
                        <a href="index.php?cat=<?php echo $product['category_id']; ?>" 
                           class="inline-block bg-green-100 text-fahs-green text-sm font-medium px-3 py-1 rounded-full mb-4 hover:bg-green-200 transition-colors">
                            <?php echo htmlspecialchars($product['category_name']); ?>
                        </a>
                    <?php endif; ?>
                    
                    <h1 class="text-3xl font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($product['name']); ?></h1>
                    
                    <?php if ($product['brand']): ?>
                        <p class="text-lg text-gray-500 mb-6"><?php echo htmlspecialchars($product['brand']); ?></p>
                    <?php endif; ?>
                    
                    <!-- Health Score -->
                    <div class="bg-gray-50 rounded-xl p-6 mb-6">
                        <div class="flex items-center justify-between mb-4">
                            <span class="text-gray-600 font-medium">Health Score</span>
                            <span class="text-sm text-gray-500">Based on nutritional values</span>
                        </div>
                        <div class="flex items-center space-x-4">
                            <div class="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold <?php echo getScoreBadgeClass($product['score']); ?>">
                                <?php echo $product['score'] ?? '-'; ?>
                            </div>
                            <div>
                                <div class="text-xl font-semibold text-gray-800"><?php echo getScoreLabel($product['score']); ?></div>
                                <div class="text-sm text-gray-500">out of 100 points</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Additives Status -->
                    <?php if ($product['additives_status']): ?>
                        <div class="flex items-center mb-6">
                            <div class="w-10 h-10 rounded-full flex items-center justify-center mr-3 <?php echo stripos($product['additives_status'], 'No') !== false ? 'bg-green-100 text-green-600' : 'bg-orange-100 text-orange-600'; ?>">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                    <?php if (stripos($product['additives_status'], 'No') !== false): ?>
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                    <?php else: ?>
                                        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                    <?php endif; ?>
                                </svg>
                            </div>
                            <div>
                                <div class="font-medium text-gray-800"><?php echo htmlspecialchars($product['additives_status']); ?></div>
                                <div class="text-sm text-gray-500">Additives Status</div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Back Button -->
                    <a href="index.php<?php echo $product['category_id'] ? '?cat=' . $product['category_id'] : ''; ?>" 
                       class="inline-flex items-center text-fahs-green hover:underline">
                        <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                        </svg>
                        Back to Products
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Nutritional Information -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <!-- Nutrition Facts -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-2xl shadow-lg p-8">
                    <h2 class="text-xl font-bold text-gray-800 mb-6">Nutritional Information</h2>
                    <p class="text-gray-500 text-sm mb-6">Values per 100g serving</p>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <!-- Calories -->
                        <div class="bg-gray-50 rounded-xl p-4">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-gray-600">Calories</span>
                                <span class="font-semibold text-gray-800"><?php echo $product['calories'] !== null ? $product['calories'] . ' kcal' : 'N/A'; ?></span>
                            </div>
                            <?php if ($product['calories']): ?>
                                <div class="nutrition-bar">
                                    <div class="nutrition-bar-fill bg-orange-400" style="width: <?php echo min(100, ($product['calories'] / 500) * 100); ?>%"></div>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Protein -->
                        <div class="bg-gray-50 rounded-xl p-4">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-gray-600">Protein</span>
                                <span class="font-semibold text-gray-800"><?php echo $product['protein'] !== null ? $product['protein'] . ' g' : 'N/A'; ?></span>
                            </div>
                            <?php if ($product['protein']): ?>
                                <div class="nutrition-bar">
                                    <div class="nutrition-bar-fill bg-blue-400" style="width: <?php echo min(100, ($product['protein'] / 30) * 100); ?>%"></div>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Sugar -->
                        <div class="bg-gray-50 rounded-xl p-4">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-gray-600">Sugar</span>
                                <span class="font-semibold text-gray-800"><?php echo $product['sugar'] !== null ? $product['sugar'] . ' g' : 'N/A'; ?></span>
                            </div>
                            <?php if ($product['sugar']): ?>
                                <div class="nutrition-bar">
                                    <div class="nutrition-bar-fill bg-yellow-400" style="width: <?php echo min(100, ($product['sugar'] / 50) * 100); ?>%"></div>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Salt -->
                        <div class="bg-gray-50 rounded-xl p-4">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-gray-600">Salt</span>
                                <span class="font-semibold text-gray-800"><?php echo $product['salt'] !== null ? $product['salt'] . ' g' : 'N/A'; ?></span>
                            </div>
                            <?php if ($product['salt']): ?>
                                <div class="nutrition-bar">
                                    <div class="nutrition-bar-fill bg-red-400" style="width: <?php echo min(100, ($product['salt'] / 5) * 100); ?>%"></div>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Saturated Fat -->
                        <div class="bg-gray-50 rounded-xl p-4 sm:col-span-2">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-gray-600">Saturated Fat</span>
                                <span class="font-semibold text-gray-800"><?php echo $product['saturated_fat'] !== null ? $product['saturated_fat'] . ' g' : 'N/A'; ?></span>
                            </div>
                            <?php if ($product['saturated_fat']): ?>
                                <div class="nutrition-bar">
                                    <div class="nutrition-bar-fill bg-purple-400" style="width: <?php echo min(100, ($product['saturated_fat'] / 20) * 100); ?>%"></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Description -->
            <div>
                <div class="bg-white rounded-2xl shadow-lg p-8">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">About This Product</h2>
                    <?php if ($product['description']): ?>
                        <p class="text-gray-600 leading-relaxed">
                            <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                        </p>
                    <?php else: ?>
                        <p class="text-gray-400 italic">No description available for this product.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Related Products -->
        <?php if (!empty($relatedProducts)): ?>
            <div class="mb-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">More from <?php echo htmlspecialchars($product['category_name']); ?></h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <?php foreach ($relatedProducts as $related): ?>
                        <a href="product_details.php?id=<?php echo $related['id']; ?>" class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                            <div class="h-40 bg-gray-100 relative overflow-hidden">
                                <?php if ($related['image_url']): ?>
                                    <img src="<?php echo htmlspecialchars($related['image_url']); ?>" 
                                         alt="" 
                                         class="w-full h-full object-cover"
                                         onerror="this.style.display='none';">
                                <?php endif; ?>
                                <div class="absolute top-2 right-2 w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold <?php echo getScoreBadgeClass($related['score']); ?>">
                                    <?php echo $related['score'] ?? '-'; ?>
                                </div>
                            </div>
                            <div class="p-4">
                                <h3 class="font-semibold text-gray-800 line-clamp-2"><?php echo htmlspecialchars($related['name']); ?></h3>
                                <?php if ($related['brand']): ?>
                                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($related['brand']); ?></p>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        
    </main>
    
    <!-- Footer -->
    <footer class="bg-white border-t mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="flex items-center space-x-2 mb-4 md:mb-0">
                    <div class="w-8 h-8 bg-fahs-green rounded-full flex items-center justify-center">
                        <span class="text-white font-bold text-sm">F</span>
                    </div>
                    <span class="font-semibold text-gray-800">FAHS MAROC</span>
                </div>
                <p class="text-gray-500 text-sm">
                    &copy; <?php echo date('Y'); ?> FAHS MAROC. Your guide to food quality in Morocco.
                </p>
            </div>
        </div>
    </footer>
    
    <!-- Mobile Menu Script -->
    <script>
        document.getElementById('mobile-menu-btn')?.addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
    
</body>
</html>
